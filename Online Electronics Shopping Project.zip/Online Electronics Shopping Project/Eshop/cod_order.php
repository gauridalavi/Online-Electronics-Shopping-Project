<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "Error: User not logged in.";
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = $_POST['amount'] ?? 0;

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert order into the orders table (mark it as COD)
$orderQuery = "INSERT INTO orders (user_id, total_price, payment_method) VALUES (?, ?, 'COD')";
$stmt = $conn->prepare($orderQuery);
$stmt->bind_param("ii", $user_id, $amount);
$stmt->execute();

// Get the new order ID
$orderID = $stmt->insert_id;

// Get the cart items for the user (product_id, quantity, price)
$cartQuery = "SELECT product_id, quantity, total_price FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($cartQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Process each product in the cart
while ($row = $result->fetch_assoc()) {
    $product_id = $row['product_id'];
    $quantity = $row['quantity'];
    $price = $row['total_price']; // The total price for this cart item (can be used if needed)

    // You might want to update the product stock by decreasing the quantity (assuming a stock column exists)
    $updateStock = "UPDATE products SET stock = stock - ? WHERE id = ?";
    $stmt = $conn->prepare($updateStock);
    $stmt->bind_param("ii", $quantity, $product_id);
    $stmt->execute();

    // Optionally, you can add logic here to handle product availability checks
}

// Clear the cart after successful order
$clearCart = "DELETE FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($clearCart);
$stmt->bind_param("i", $user_id);
$stmt->execute();

$stmt->close();
$conn->close();

// Redirect to a success page
header("Location: success.php?orderID=" . $orderID);
exit();
?>
