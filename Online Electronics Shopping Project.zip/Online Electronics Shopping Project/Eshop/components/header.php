<?php
// Start the session

// Check if a session is not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Retrieve session variables
$isLoggedIn = isset($_SESSION['isLoggedIn']) ? $_SESSION['isLoggedIn'] : false;
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Retrieve session variables
$isLoggedIn = isset($_SESSION['isLoggedIn']) ? $_SESSION['isLoggedIn'] : false;
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';  // Use user_id instead of username

// Initialize cart count
$cartCount = 0;

// If the user is logged in, retrieve their cart items
if ($isLoggedIn && !empty($user_id)) {
    // Query to get the total quantity of items in the cart for this user
    $sql = "SELECT SUM(quantity) as cartCount FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);  // Bind the user_id as an integer
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $cartCount = $row['cartCount'];
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElectroShop</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link rel="stylesheet" href="css/header.css">

<body>
<header>
    <div class="container header-content">
        <a href="/" class="logo">ElectroShop</a>
        <div class="search-bar">
        <form action="search.php" method="GET">
                <input type="search" name="query" placeholder="Search the store" required>
                <button type="submit">Search</button>
            </form>

        </div>
        <div class="login-container">
            <button id="loginButton" class="login-button">
                <img class="icon" src="user-icon.png" alt="User Icon"> Login
            </button>
            <div id="dropdown" class="dropdown">
                <div class="new-customer">
                    <span>New customer?</span>
                    <a href="./signup.php" class="signup-link">Register</a>
                </div>
                <a href="./profile.php" id="profileLink">👤 My Profile</a>
                <a href="./order_history.php" id="ordersLink">📦 Orders</a>
                <a href="./wishlist.php" id="wishlistLink">❤️ My Wishlist</a>
                <a href="./logout.php" id="logoutLink" class="logout" style="display: none;">🚪 Logout</a>
            </div>
        </div>
        <div class="user-actions">
            <a href="./my_cart.php" id="cartLink">
                <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='20' viewBox='0 0 24 23' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='9' cy='21' r='1'%3E%3C/circle%3E%3Ccircle cx='20' cy='21' r='1'%3E%3C/circle%3E%3Cpath d='M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6'%3E%3C/path%3E%3C/svg%3E" alt="Cart"> 
                Cart (<?php echo $cartCount; ?>)
            </a>
        </div>
    </div>
</header>


<!-- Navigation Bar with Categories -->
<nav>
    <div class="navbar">
        <button onclick="toggleMenu()" aria-expanded="false" aria-controls="category-menu">
            <span class="icon"> ☰ </span> Shop By Category
        </button>

        <!-- Navbar List -->
        <ul class="nav-list">
            <li><a href="./index.php">Home</a></li>
            <li><a href="./about_us.php">About</a></li>
            <li><a href="./order_history.php">Orders</a></li>
            <li><a href="./shop.php">Shop</a></li>
            <li><a href="./contact_form.php">Contact</a></li>
        </ul>
    </div>

    <div class="menu" id="category-menu">
        <ul>
            <?php
            // Fetch categories
            $categories = $conn->query("SELECT * FROM categories");

            while ($category = $categories->fetch_assoc()) {
                echo "<li>";
                echo "<a href='./shop.php?category_id={$category['id']}'>{$category['name']}</a>";
                echo "<ul>";

                // Fetch brands under this category
                $brands = $conn->query("SELECT * FROM brands WHERE category_id = {$category['id']}");
                while ($brand = $brands->fetch_assoc()) {
                    echo "<li><a href='./shop.php?category_id={$category['id']}&brand_id={$brand['id']}'>{$brand['name']}</a></li>";
                }

                echo "</ul>";
                echo "</li>";
            }
            ?>
        </ul>
    </div>

    <script>
        function toggleMenu() {
            const menu = document.getElementById('category-menu');
            const button = document.querySelector('.navbar button');
            menu.classList.toggle('active');
            const isExpanded = menu.classList.contains('active');
            button.setAttribute('aria-expanded', isExpanded);
        }
    </script>
</nav>

<script>
    let isLoggedIn = <?php echo json_encode($isLoggedIn); ?>;
    let username = <?php echo json_encode($username); ?>;

    const loginButton = document.getElementById('loginButton');
    const logoutLink = document.getElementById('logoutLink');
    const profileLink = document.getElementById('profileLink');
    const ordersLink = document.getElementById('ordersLink');

    function updateLoginState() {
        if (isLoggedIn) {
            loginButton.textContent = username || 'User';
            logoutLink.style.display = 'block';
        } else {
            loginButton.textContent = 'Login';
            logoutLink.style.display = 'none';
        }

        [profileLink, ordersLink].forEach(link => {
            link.addEventListener('click', (e) => {
                if (!isLoggedIn) {
                    e.preventDefault();
                    window.location.href = './login.php';
                }
            });
        });
    }

    loginButton.addEventListener('click', () => {
        if (!isLoggedIn) {
            window.location.href = './login.php';
        }
    });

    logoutLink.addEventListener('click', (e) => {
        e.preventDefault();
        window.location.href = './logout.php';
    });

    updateLoginState();
</script>


<?php $conn->close(); ?>

</body>
</html>