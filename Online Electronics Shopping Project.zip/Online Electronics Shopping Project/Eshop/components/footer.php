

<footer>
<div class="footer-main">
    <div class="footer-column">
      <h3>Account Detail</h3>
      <ul>
        <li><a href="./index.php">Home</a></li>
        <li><a href="./about_us.php">About us</a></li>
        <li><a href="./search.php">Search</a></li>
        <li><a href="./my_cart.php">Cart</a></li>
        <li><a href="#">Checkout</a></li>
      </ul>
    </div>
    <div class="footer-column">
      <h3>Quick Link</h3>
      <ul>
        <li><a href="./profile.php">My Profile</a></li>
        <li><a href="./change_password.php">Change Password</a></li>
        <li><a href="./order_history.php">Order History</a></li>
        <li><a href="./wishlist.php">My Wishlist</a></li>
      </ul>
    </div>
    <div class="footer-column">
      <h3>Quick Link</h3>
      <ul>
        <li><a href="./login.php">Login</a></li>
        <li><a href="./contact_form.php">Contact Us</a></li>
      </ul>
    </div>
    <div class="footer-column">
      <h3>GET IN TOUCH</h3>
      <p>E-MAIL: info@electroshop.com</p>
      <p>WHATS-APP: +91-123 456 789</p>
      <p>CONTACT NO.: +91 (123)-4567890</p>
      
    </div>
  </div>
  
  <div class="footer-bottom">
    <p>Copyright © 2024, ElectroShop All Rights Reserved</p>
  </div>
</footer>




     
     
