<?php
session_start();
include('database/db_connect.php');

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$user_id = $_SESSION['user_id'];

$first_name = $data['first_name'];
$phone = $data['phone'];
$address = $data['address'];
$city = $data['city'];
$state = $data['state'];
$zip = $data['zip'];

$updateQuery = $conn->prepare("UPDATE userprofile SET first_name = ?, phone = ?, address = ?, city = ?, state = ?, zip = ? WHERE user_id = ?");
$updateQuery->bind_param("ssssssi", $first_name, $phone, $address, $city, $state, $zip, $user_id);

if ($updateQuery->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["error" => "Failed to update profile."]);
}
?>
