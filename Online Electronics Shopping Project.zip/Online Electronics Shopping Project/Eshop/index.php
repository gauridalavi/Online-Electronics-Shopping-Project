<?php
include('database/db_connect.php'); // database connection file

// Fetch Trending Products
$trendingQuery = "SELECT * FROM products WHERE trending = 1 LIMIT 6";
$trendingProducts = $conn->query($trendingQuery);

// Fetch Best Selling Products
$bestSellingQuery = "SELECT * FROM products WHERE best_selling = 1 LIMIT 6";
$bestSellingProducts = $conn->query($bestSellingQuery);
?>

<?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/Styles.css">
    <link rel="stylesheet" href="css/footer.css">

</head>
<body>

   <!-- Slider-Section HTML Code STARTS -->

   <div class="slider-container">
        
        <div class="slider">
          <div class="slide">
            <img src="images/Slider1.jpg" alt="Realme 8i Promotion">
          </div>
          <div class="slide">
            <img src="images/slider2.jpg" alt="Intel Gaming Promotion">
          </div>
          <div class="slide">
            <img src="images/slider3.jpg" alt="Motorola Edge Promotion">
          </div>
          <div class="slide">
            <img src="images/slider4.jpg" alt="Motorola Edge Promotion">
          </div>
        </div>
              
          <div class="dots">
          <div class="dot active"></div>
          <div class="dot"></div>
          <div class="dot"></div>
          <div class="dot"></div>


        </div>
        
      </div>
      <script src="js/slider.js"></script>
   <!--  Trending Products Section -->
   <section class="product-section">
    <h2>🔥 Trending Products</h2>
    <div class="product-container">
        <?php while ($product = $trendingProducts->fetch_assoc()): ?>
            <div class="product-card">
    <img src="Admin/uploads/productImages/<?= $product['id']; ?>/<?= basename($product['image_main']); ?>" 
         alt="<?= htmlspecialchars($product['name']); ?>">
    <div class="product-details">
        <h3><?= htmlspecialchars($product['name']); ?></h3>
        <p class="price">₹<?= $product['price']; ?>
            <?php if ($product['original_price']): ?>
                <span class="original-price">₹<?= $product['original_price']; ?></span>
            <?php endif; ?>
        </p>
        <a href="products_details.php?id=<?= $product['id']; ?>" class="view-details">View Details</a>
    </div>
</div>

        <?php endwhile; ?>
    </div>
</section>

    <!--  Best Selling Products Section -->
    <section class="product-section">
        <h2>🏆 Best Selling Products</h2>
        <div class="product-container">
            <?php while ($product = $bestSellingProducts->fetch_assoc()): ?>
                <div class="product-card">
                <img src="Admin/uploads/productImages/<?php echo $product['id']; ?>/<?php echo basename($product['image_main']); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>">
                <div class="product-details">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="price">₹<?php echo $product['price']; ?>
                    <?php if ($product['original_price']): ?>
                <span class="original-price">₹<?= $product['original_price']; ?></span>
            <?php endif; ?>
                </p>
                    <a href="products_details.php?id=<?php echo $product['id']; ?>" class="view-details">View Details</a>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
        
      <!-- Slider-Section HTML Code ENDS -->

<section class="brands-section">
  <div class="section-header">
      <h2 class="section-title">Our Brands</h2>
  </div>
  
  <div class="brands-container">
      <div class="brand-item" style="animation-delay: 0.1s">
          <img src="images/samsunglogodesktop.svg" alt="Samsung" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.2s">
          <img src="images/sony.svg" alt="Sony" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.3s">
          <img src="images/lglogodesktop.svg" alt="LG" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.4s">
          <img src="images/delllogodesktop.svg" alt="Dell" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.5s">
          <img src="images/hplogodesktop.svg" alt="HP" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.6s">
          <img src="images/asuslogodesktop.svg" alt="Asus" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.7s">
          <img src="images/oppologodesktop.svg" alt="Oppo" class="brand-logo">
      </div>
      <div class="brand-item" style="animation-delay: 0.8s">
          <img src="images/vivologodesktop.svg" alt="Vivo" class="brand-logo">
      </div>
  </div>
</section>


<div class="features-container">
  <div class="feature-item">
      <svg class="feature-icon" viewBox="0 0 24 24">
          <path d="M3 13h1v7c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-7h1c.6 0 1-.4 1-1V8c0-1.1-.9-2-2-2h-3V3c0-.6-.4-1-1-1H8c-.6 0-1 .4-1 1v3H4C2.9 6 2 6.9 2 8v4c0 .6.4 1 1 1z"/>
      </svg>
      <div class="feature-content">
          <h3 class="feature-title">Instant Delivery</h3>
          <p class="feature-description">One day shipping onss all order</p>
      </div>
  </div>
  <div class="feature-item">
      <svg class="feature-icon" viewBox="0 0 24 24">
          <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z"/>
      </svg>
      <div class="feature-content">
          <h3 class="feature-title">Online Support 24/7</h3>
          <p class="feature-description">Support online 24 hours a day</p>
      </div>
  </div>
  <div class="feature-item">
      <svg class="feature-icon" viewBox="0 0 24 24">
          <path d="M18 6h-2c0-2.2-1.8-4-4-4S8 3.8 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2z"/>
      </svg>
      <div class="feature-content">
          <h3 class="feature-title">Try and Buy</h3>
          <p class="feature-description">Try Product, If you like it then buy it</p>
      </div>
  </div>
  <div class="feature-item">
      <svg class="feature-icon" viewBox="0 0 24 24">
          <path d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1z"/>
      </svg>
      <div class="feature-content">
          <h3 class="feature-title">Instant Discount</h3>
          <p class="feature-description">Upto 50% instant discount on all product</p>
      </div>
  </div>
  <div class="feature-item">
      <svg class="feature-icon" viewBox="0 0 24 24">
          <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/>
      </svg>
      <div class="feature-content">
          <h3 class="feature-title">Secure Payment</h3>
          <p class="feature-description">All cards accepted</p>
      </div>
  </div>
</div>

<?php include('./components/footer.php'); ?>    
</body>
</html>