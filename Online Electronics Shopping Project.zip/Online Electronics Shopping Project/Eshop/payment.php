<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check user authentication
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    header("Location: login.php?return=checkout.php");
    exit();
}

// Check if customer details are available in session
if (!isset($_SESSION['customer_details'])) {
    die("Error: Customer details not found.");
}

// Retrieve customer details from session
$customerDetails = $_SESSION['customer_details'];
$customerName    = $customerDetails['name'];
$customerEmail   = $customerDetails['email'];
$customerContact = $customerDetails['phone'];

// Get user ID
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    echo "Error: User ID not found in session.";
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cart items for the logged-in user
$sql = "SELECT * FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate the total price
$total_price = 0;
foreach ($cart_items as $item) {
    $total_price += $item['total_price'] * $item['quantity']; // Correct total price calculation
}

// Convert total price to paise (Razorpay accepts amount in paise)
$total_price_in_paise = $total_price * 100;

// Razorpay credentials
$keyId     = "rzp_test_dgqSY6c4G84QHu";
$keySecret = "bGta1T9XH4mpioSptQCBQ3XH";
$orderId   = "ORDER" . time(); // Unique order ID
$currency  = "INR";

require 'vendor/autoload.php';
use Razorpay\Api\Api;

$api = new Api($keyId, $keySecret);

// Create Razorpay order with the total amount from the cart
try {
    $order = $api->order->create([
        'receipt'         => $orderId,
        'amount'          => $total_price_in_paise, // Amount in paise
        'currency'        => $currency,
        'payment_capture' => 1 // Auto capture payment
    ]);
} catch (Exception $e) {
    die('Error creating Razorpay order: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      color: #333;
    }
    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 100%;
      max-width: 400px;
      margin: auto;
    }
    h2 {
      font-size: 24px;
      color: #2c3e50;
      margin-bottom: 30px;
    }
    button {
      display: block;
      width: 100%;
      padding: 15px;
      margin: 10px 0;
      font-size: 16px;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.3s;
      font-weight: bold;
    }
    #pay-button { background-color: #3399cc; }
    #cod-button { background-color: #28a745; }
    button:hover { opacity: 0.8; }
    button:active { transform: scale(0.98); }
    button:focus { outline: none; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Select Payment Method</h2>
    <button id="pay-button">Pay with Razorpay</button>
    <button id="cod-button">Cash on Delivery</button>
  </div>

  <script>
    var options = {
      "key": "<?php echo $keyId; ?>",
      "amount": "<?php echo $total_price_in_paise; ?>", // Amount in paise
      "currency": "<?php echo $currency; ?>",
      "name": "ElectroShop",
      "description": "Order #<?php echo $orderId; ?>",
      "image": "your-logo-url", // Replace with your logo URL if needed
      "order_id": "<?php echo $order['id']; ?>",
      "handler": function (response) {
          alert('Payment Successful! Payment ID: ' + response.razorpay_payment_id);
          window.location.href = "order_confirm.php?payment_id=" + response.razorpay_payment_id;
      },
      "prefill": {
          "name": "<?php echo $customerName; ?>",
          "email": "<?php echo $customerEmail; ?>",
          "contact": "<?php echo $customerContact; ?>"
      },
      "theme": {
          "color": "#3399cc"
      }
    };

    var rzp = new Razorpay(options);
    document.getElementById('pay-button').onclick = function (e) {
      rzp.open();
      e.preventDefault();
    };

    document.getElementById('cod-button').onclick = function () {
    alert('Order Confirmed! You selected Cash on Delivery.');
    window.location.href = "order_confirm.php?method=cod"; // Pass 'cod' method
};

  </script>
</body>
</html>
