<?php
// Include the database connection file
include('database/db_connect.php'); // Adjust this path if necessary

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_POST['user_id']); // Retrieve user ID
    $product_id = intval($_POST['product_id']); // Retrieve product ID

    // Validate input data
    if ($user_id > 0 && $product_id > 0) {
        // Check if the product is already in the wishlist
        $query = "SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("ii", $user_id, $product_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "Product already in wishlist!";
            } else {
                // Insert the product into the wishlist
                $insert_query = "INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)";
                $insert_stmt = $conn->prepare($insert_query);

                if ($insert_stmt) {
                    $insert_stmt->bind_param("ii", $user_id, $product_id);
                    if ($insert_stmt->execute()) {
                        echo "Product added to wishlist!";
                    } else {
                        echo "Error adding product to wishlist: " . $insert_stmt->error;
                    }
                } else {
                    echo "Failed to prepare the insert statement: " . $conn->error;
                }
            }
        } else {
            echo "Failed to prepare the select statement: " . $conn->error;
        }
    } else {
        echo "Invalid input data.";
    }
} else {
    echo "Invalid request.";
}

// Close the database connection
$conn->close();
?>
