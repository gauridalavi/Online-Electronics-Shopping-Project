<?php
// Start the session
session_start();

// Include the database connection file
include('database/db_connect.php'); // Adjust this path if necessary

// Check if the user is logged in
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    // Redirect to login page
    header("Location: login.php?return=wishlist.php");
    exit();
}

// Fetch user data from the session
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    echo "Error: User ID not found in session.";
    exit();
}

// Handle Add to Wishlist functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id']);

    if ($product_id > 0) {
        // Check if the product is already in the wishlist
        $query = "SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("ii", $user_id, $product_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $message = "Product already in wishlist!";
            } else {
                // Insert the product into the wishlist
                $insert_query = "INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)";
                $insert_stmt = $conn->prepare($insert_query);

                if ($insert_stmt) {
                    $insert_stmt->bind_param("ii", $user_id, $product_id);
                    if ($insert_stmt->execute()) {
                        $message = "Product added to wishlist!";
                    } else {
                        $message = "Error adding product to wishlist: " . $insert_stmt->error;
                    }
                } else {
                    $message = "Failed to prepare the insert statement: " . $conn->error;
                }
            }
        } else {
            $message = "Failed to prepare the select statement: " . $conn->error;
        }
    } else {
        $message = "Invalid product ID.";
    }
}

// Fetch wishlist items for the logged-in user
$wishlistItems = [];
$query = "SELECT w.*, p.name AS product_name, p.image_main AS image_main, p.price 
          FROM wishlist w
          JOIN products p ON w.product_id = p.id
          WHERE w.user_id = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $wishlistItems[] = $row;
        }
    }
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
    <?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Wishlist</title>
    <link rel="stylesheet" href="css/wishlist_form.css">
    <link rel="stylesheet" href="css/footer.css">


</head>
<body>
<div class="form-body">
<h1>My Wishlist</h1>

<!-- Success/Error Message -->
<?php if (!empty($message)): ?>
    <p class="success" style="text-align: center; color: green;"><?php echo htmlspecialchars($message); ?></p>
<?php endif; ?>

<!-- Wishlist Table -->
<?php if (!empty($wishlistItems)): ?>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($wishlistItems as $item): ?>
                <tr>
                    <td>
                        <img src="Admin/<?php echo htmlspecialchars($item['image_main']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>" style="width: 50px; height: 50px; border-radius: 5px;">
                        <?php echo htmlspecialchars($item['product_name']); ?>
                    </td>
                    <td>₹<?php echo htmlspecialchars($item['price']); ?></td>
                    <td>
                    <form action="remove_from_wishlist.php" method="POST">
    <input type="hidden" name="wishlist_id" value="<?php echo $item['id']; ?>">
    <button type="submit" class="btn-remove">Remove</button>
</form>

                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p style="text-align: center;">Your wishlist is empty.</p>
<?php endif; ?>

<!-- Wishlist Buttons -->
<div class="wishlist-buttons">
    <button class="btn-continue" onclick="location.href='index.php';">Continue Shopping</button>
</div>
</div>
<?php include('./components/footer.php'); ?>

</body>
</html>
