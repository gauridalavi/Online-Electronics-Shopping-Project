<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle search input
$search = "";
$whereClause = "";

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $whereClause = "WHERE p.status LIKE '%$search%'";
}

// Fetch payments based on search query
$payment_query = "SELECT p.*, o.full_name, o.email 
                  FROM payment p
                  JOIN orders o ON p.order_id = o.id
                  $whereClause
                  ORDER BY p.created_at ASC";
$result = $conn->query($payment_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Payment Reports</title>
    <style>
            body { 
                font-family: Arial, sans-serif; 
                background-color: #f8f9fa;
                padding: 20px;
                }
            .container {
                max-width: 1200px; 
                background: white;
                padding: 20px;
                border-radius: 8px;
                margin: auto;
                box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
         }
        h2 { 
            text-align: center; 
            margin-bottom: 20px; 
            color: #333;
         }
        table {
             width: 100%; 
             border-collapse: collapse; 
             background: white; 
             box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
             }
        th, td {
             padding: 12px; 
             text-align: center; 
             border: 1px solid #ddd;
             }
        th {
             background:rgb(42, 113, 164);
             color: white; 
             text-transform: uppercase;
             }
        tr:nth-child(even)
         { 
            background-color: #f2f2f2;
         }
        .search-form { 
            text-align: center;
             margin-bottom: 20px; 
            }
        .search-form input {
             padding: 8px; 
             width: 250px; 
             border: 1px solid #ccc;
              border-radius: 4px; 
            }
        .search-form button {
             padding: 8px 12px;
              background: #007BFF;
               color: white; 
               border: none;
                cursor: pointer; }
    </style>
</head>
<body>

<div class="container">
    <h2>Users Payment Reports</h2>

    <!-- Search Bar -->
    <form method="GET" class="search-form">
        <input type="text" name="search" placeholder="Search 'completed' or 'pending'" value="<?php echo $search; ?>">
        <button type="submit">Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Payment Method</th>
                <th>Payment ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['order_id']; ?></td>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo strtoupper($row['payment_method']); ?></td>
                    <td><?php echo $row['payment_id']; ?></td>
                    <td>₹<?php echo number_format($row['amount'], 2); ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
