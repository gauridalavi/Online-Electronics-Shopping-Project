<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get current date
$current_date = date('Y-m-d');

// Fetch daily orders
$query = "SELECT * FROM orders WHERE DATE(order_date) = '$current_date' ORDER BY order_date ASC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Order Report</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px; }
        .container { max-width: 1200px; background: white; padding: 20px; border-radius: 8px; margin: auto; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); text-align: center; }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 12px; text-align: center; border: 1px solid #ddd; }
        th { background: #007BFF; color: white; text-transform: uppercase; }
        tr:nth-child(even) { background-color: #f2f2f2; }
    </style>
</head>
<body>

<div class="container">
    <h2>Daily Order Report</h2>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Total Amount</th>
                <th>Payment Status</th>
                <th>Order Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['full_name']; ?></td>
                    <td>₹<?php echo number_format($row['total_price'], 2); ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td><?php echo date('d M Y, h:i A', strtotime($row['order_date'])); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
