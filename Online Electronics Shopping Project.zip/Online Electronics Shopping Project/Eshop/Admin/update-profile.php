<?php
session_start();

// Debug: Check if session is working
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('Access denied! Please log in again.'); window.location.href='admin_login.php';</script>";
    exit;
}

// Get Admin ID from session
$admin_id = $_SESSION['admin_id'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch admin details
$sql = "SELECT username, password FROM admin WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

// Debugging: Check if admin exists
if (!$admin) {
    echo "<script>alert('Admin not found!'); window.location.href='admin_login.php';</script>";
    exit;
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $old_password = trim($_POST['old_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Verify old password
    if (!password_verify($old_password, $admin['password'])) {
        echo "<script>alert('Old password is incorrect.'); window.location.href='update-profile.php';</script>";
        exit;
    }

    // Ensure new passwords match
    if ($new_password !== $confirm_password) {
        echo "<script>alert('New password and confirm password do not match.'); window.location.href='update-profile.php';</script>";
        exit;
    }

    // Update password
    $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $update_sql = "UPDATE admin SET password = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("si", $new_hashed_password, $admin_id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Profile updated successfully!'); window.location.href='admin-dashboard.php';</script>";
        exit;
    } else {
        echo "<script>alert('Error updating profile. Try again!');</script>";
    }

    $update_stmt->close();
}

$conn->close();
?>
<?php include('./components/admin_header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <link rel="stylesheet" href="css/update_profile.css">

   
</head>
<body>
<div class="form-body">

    <div class="profile-card">
        <h1>Update Profile</h1>
        <form action="update-profile.php" method="POST">
            <input 
                type="text" 
                class="input-field" 
                name="username" 
                value="<?php echo htmlspecialchars($admin['username']); ?>" 
                readonly
            >
            <input 
                type="password" 
                class="input-field" 
                name="old_password" 
                placeholder="Enter old password" 
                required
            >
            <input 
                type="password" 
                class="input-field" 
                name="new_password" 
                placeholder="Enter new password" 
                required
            >
            <input 
                type="password" 
                class="input-field" 
                name="confirm_password" 
                placeholder="Confirm new password" 
                required
            >
            <button type="submit" class="update-btn">Update Now</button>
        </form>
    </div>
</div>
</body>
</html>
