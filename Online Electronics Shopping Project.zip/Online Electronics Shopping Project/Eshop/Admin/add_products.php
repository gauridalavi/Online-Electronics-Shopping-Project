<?php include('./components/admin_header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add Products</title>
    <link rel="stylesheet" href="css/addProducts_form.css">
</head>
<body>

    <div class="form-body">
    <div class="admin-container">
        <h1>Add New Product</h1>
        <!-- PHP Code to Fetch Categories and Brands -->
        <?php
        // Connect to the database
        $conn = new mysqli('localhost', 'root', '', 'eshop');

        // Fetch categories
        $categories = $conn->query("SELECT * FROM categories");

        // Fetch brands
        $brands = $conn->query("SELECT * FROM brands");
        ?>
        
        <form action="process_add_products.php" method="POST" enctype="multipart/form-data">
            <!-- Product Name -->
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" required>

            <!-- Product Description -->
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>

            <!-- Category -->
            <label>Category:</label>
            <select name="category_id" required>
                <?php
                $categories = $conn->query("SELECT * FROM categories");
                while ($category = $categories->fetch_assoc()) {
                    echo "<option value='" . $category['id'] . "'>" . htmlspecialchars($category['name']) . "</option>";
                }
                ?>
            </select>

            <!-- Brand -->
            <label>Brand:</label>
            <select name="brand_id" required>
                <?php
                $brands = $conn->query("SELECT * FROM brands");
                while ($brand = $brands->fetch_assoc()) {
                    echo "<option value='" . $brand['id'] . "'>" . htmlspecialchars($brand['name']) . "</option>";
                }
                ?>
            </select>

            <!-- Stock Quantity -->
            <label for="stock_quantity">Stock Quantity:</label>
            <input type="number" id="stock_quantity" name="stock_quantity" required>

            <!-- Product Images -->
            <label for="image_main">Main Image:</label>
            <input type="file" name="image_main" id="image_main" required><br>

            <label for="image_thumb1">Thumbnail 1:</label>
            <input type="file" name="image_thumb1" id="image_thumb1"><br>

            <label for="image_thumb2">Thumbnail 2:</label>
            <input type="file" name="image_thumb2" id="image_thumb2"><br>

            <!-- Price -->
            <label for="price">Price (₹):</label>
            <input type="number" id="price" name="price" required>

            <!-- Original Price -->
            <label for="original_price">Original Price (₹):</label>
            <input type="number" id="original_price" name="original_price">

            <!-- Discount -->
            <label for="discount">Discount (%):</label>
            <input type="number" id="discount" name="discount" step="0.01">

            <!-- Trending Checkbox -->
            <label for="trending">Trending:</label>
            <input type="checkbox" id="trending" name="trending" value="1">

            <!-- Best Selling Checkbox -->
            <label for="best_selling">Best Selling:</label>
            <input type="checkbox" id="best_selling" name="best_selling" value="1">

            <!-- Submit Button -->
            <button type="submit" class="btn">Add Product</button>
        </form>
    </div>
    </div>
</body>
</html>
