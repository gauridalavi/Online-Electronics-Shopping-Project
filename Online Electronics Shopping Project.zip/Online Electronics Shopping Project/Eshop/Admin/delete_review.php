<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['review_id'])) {
    $review_id = (int) $_POST['review_id'];

    // Delete query
    $delete_query = "DELETE FROM reviews WHERE id = $review_id";
    if ($conn->query($delete_query) === TRUE) {
        echo "<script>alert('Review deleted successfully!'); window.location.href = 'admin_reviews.php';</script>";
    } else {
        echo "<script>alert('Error deleting review.'); window.location.href = 'admin_reviews.php';</script>";
    }
}

$conn->close();
?>
