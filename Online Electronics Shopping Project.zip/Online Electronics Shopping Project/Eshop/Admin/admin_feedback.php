<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all reviews with product details
$review_query = "SELECT r.id, r.product_id, p.name AS product_name, r.name, r.rating, r.comments, r.created_at 
                 FROM reviews r
                 JOIN products p ON r.product_id = p.id
                 ORDER BY r.created_at DESC";
$result = $conn->query($review_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Reviews</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; padding: 20px; }
        .container { max-width: 1200px; background: white; padding: 20px; border-radius: 8px; margin: auto; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); }
        h2 { text-align: center; margin-bottom: 20px; color: #333; }
        table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); }
        th, td { padding: 12px; text-align: center; border: 1px solid #ddd; }
        th { background: #007BFF; color: white; text-transform: uppercase; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .delete-btn { background: red; color: white; padding: 6px 10px; border: none; cursor: pointer; }
    </style>
</head>
<body>

<div class="container">
    <h2>Customer Reviews</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>User Name</th>
                <th>Rating</th>
                <th>Comments</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['product_name']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['rating']; ?> ⭐</td>
                    <td><?php echo $row['comments']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <form action="delete_review.php" method="POST">
                            <input type="hidden" name="review_id" value="<?php echo $row['id']; ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
