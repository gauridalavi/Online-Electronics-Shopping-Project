<?php
// Start output buffering
ob_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate required fields
if (
    empty($_POST['category_id']) ||
    empty($_POST['brand_id']) ||
    empty($_POST['product_name']) ||
    empty($_POST['description']) ||
    empty($_POST['price'])
) {
    die("Error: All required fields must be filled out.");
}

// Get form data after validation
$category_id = $_POST['category_id'];
$brand_id = $_POST['brand_id'];
$stock_quantity = $_POST['stock_quantity'];
$name = $_POST['product_name'];
$description = $_POST['description'];
$price = $_POST['price'];
$original_price = $_POST['original_price'] ?? NULL;
$discount = $_POST['discount'] ?? 0;
// Get checkbox values (1 if checked, 0 otherwise)
$trending = isset($_POST['trending']) ? 1 : 0;
$best_selling = isset($_POST['best_selling']) ? 1 : 0;

// Validate category_id and brand_id
if (!is_numeric($category_id) || !is_numeric($brand_id)) {
    die("Error: category_id and brand_id must be numeric.");
}

// Check if the category_id exists
$category_check = $conn->query("SELECT id FROM categories WHERE id = $category_id");
if ($category_check->num_rows == 0) {
    die("Error: Invalid category_id.");
}

// Check if the brand_id exists
$brand_check = $conn->query("SELECT id FROM brands WHERE id = $brand_id");
if ($brand_check->num_rows == 0) {
    die("Error: Invalid brand_id.");
}

// Insert product into database WITHOUT images first
$sql = "INSERT INTO products 
    (category_id, brand_id,stock_quantity, name, description, price, original_price, discount,trending, best_selling) 
    VALUES 
    ('$category_id', '$brand_id','$stock_quantity', '$name', '$description', '$price', '$original_price', '$discount','$trending', '$best_selling')";
if ($conn->query($sql) === TRUE) {
    // Get the auto-generated product ID
    $product_id = $conn->insert_id;
} else {
    die("Error: " . $conn->error);
}

// Define the product image folder path
$product_folder = __DIR__ . '/uploads/productImages/' . $product_id . '/';

// Ensure the folder exists
if (!is_dir($product_folder)) {
    mkdir($product_folder, 0755, true); // Create the folder if it doesn't exist
}

// Initialize variables for file uploads
$image_main = '';
$image_thumb1 = '';
$image_thumb2 = '';

// Handle file uploads
if (isset($_FILES['image_main']) && $_FILES['image_main']['error'] == 0) {
    $image_main = 'uploads/productImages/' . $product_id . '/' . basename($_FILES['image_main']['name']);
    move_uploaded_file($_FILES['image_main']['tmp_name'], $product_folder . basename($_FILES['image_main']['name']));
} else {
    die('Error: Main image is required.');
}

if (isset($_FILES['image_thumb1']) && $_FILES['image_thumb1']['error'] == 0) {
    $image_thumb1 = 'uploads/productImages/' . $product_id . '/' . basename($_FILES['image_thumb1']['name']);
    move_uploaded_file($_FILES['image_thumb1']['tmp_name'], $product_folder . basename($_FILES['image_thumb1']['name']));
}

if (isset($_FILES['image_thumb2']) && $_FILES['image_thumb2']['error'] == 0) {
    $image_thumb2 = 'uploads/productImages/' . $product_id . '/' . basename($_FILES['image_thumb2']['name']);
    move_uploaded_file($_FILES['image_thumb2']['tmp_name'], $product_folder . basename($_FILES['image_thumb2']['name']));
}

// Update the product in the database with the image paths
$sql_update = "UPDATE products 
    SET image_main = '$image_main', 
        image_thumb1 = '$image_thumb1', 
        image_thumb2 = '$image_thumb2' 
    WHERE id = $product_id";

if ($conn->query($sql_update) === TRUE) {
    echo "<script>
        alert('Product added successfully!');
        window.location.href = 'admin-dashboard.php';
    </script>";
    exit();
} else {
    echo "Error updating product images: " . $conn->error;
}




// Close connection
$conn->close();
?>
