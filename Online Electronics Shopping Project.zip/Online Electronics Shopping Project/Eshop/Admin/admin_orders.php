<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == 'admin' && $password == '111') {
        $_SESSION['isAdminLoggedIn'] = true;
        header("Location: admin_orders.php");
        exit();
    } else {
        echo "Invalid username or password.";
    }
}

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $conn->real_escape_string($_POST['status']);

    $updateQuery = "UPDATE orders SET status = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    if ($updateStmt) {
        $updateStmt->bind_param("si", $new_status, $order_id);
        if ($updateStmt->execute()) {
            echo "<script>alert('Order status updated successfully.'); window.location.href = 'admin_orders.php';</script>";
            exit();
        } else {
            echo "<script>alert('Error updating order status.'); window.location.href = 'admin_orders.php';</script>";
            exit();
        }
        $updateStmt->close();
    } else {
        die("Error preparing SQL statement: " . $conn->error);
    }
}

// Fetch orders with related order items and products
$orderQuery = "
    SELECT 
        orders.id AS order_id, 
        orders.order_date, 
        orders.shipping_address, 
        orders.payment_method, 
        orders.total_price, 
        orders.status, 
        orders.full_name, 
        orders.email, 
        orders.phone_no,
        GROUP_CONCAT(products.name SEPARATOR '|') AS product_names,
        GROUP_CONCAT(products.image_main SEPARATOR '|') AS product_images
    FROM orders
    JOIN order_items ON orders.id = order_items.order_id
    JOIN products ON order_items.product_id = products.id
    GROUP BY orders.id
    ORDER BY orders.order_date ASC";


$orderResult = $conn->query($orderQuery);
if (!$orderResult) {
    die("Error fetching orders: " . $conn->error);
}
?>
<?php include('./components/admin_header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Orders</title>
    <link rel="stylesheet" href="css/manage_ordersForm.css">
</head>
<body>
<div class="form-body">
    <div class="container">
        <h2> Manage Orders</h2>
        <?php if ($orderResult->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Products</th>
                        <th>Shipping Address</th>
                        <th>Payment</th>
                        <th>Total Price</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = $orderResult->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['order_id']) ?></td>
                            <td><?= htmlspecialchars($order['order_date']) ?></td>
                            <td><?= htmlspecialchars($order['full_name']) ?></td>
                            <td><?= htmlspecialchars($order['email']) ?></td>
                            <td><?= htmlspecialchars($order['phone_no']) ?></td>
                            <td>
                                <?php
                              $productNames = explode("|", $order['product_names']);
                              $productImages = explode("|", $order['product_images']);
                              
                                foreach ($productNames as $index => $productName):
                                ?>
                                    <div class="product-item">
                                        <img src="<?= htmlspecialchars($productImages[$index]) ?>" alt="Product" class="product-image">
                                        <p><?= htmlspecialchars($productName) ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </td>
                            <td><?= htmlspecialchars($order['shipping_address']) ?></td>
                            <td><?= htmlspecialchars($order['payment_method']) ?></td>
                            <td>₹<?= htmlspecialchars(number_format($order['total_price'], 2)) ?></td>
                            <td><?= htmlspecialchars($order['status']) ?></td>
                            <td>
                                <form action="" method="POST">
                                    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                    <select name="status" class="status-select">
                                        <option value="Pending" <?= $order['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="Processing" <?= $order['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                                        <option value="Shipped" <?= $order['status'] == 'Shipped' ? 'selected' : '' ?>>Shipped</option>
                                        <option value="Delivered" <?= $order['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                        <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" name="update_order_status" class="update-btn">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No orders found.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
