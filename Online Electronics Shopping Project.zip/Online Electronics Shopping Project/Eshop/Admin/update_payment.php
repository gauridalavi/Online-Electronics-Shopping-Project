<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if (isset($_POST['payment_id']) && isset($_POST['status'])) {
    $payment_id = trim($_POST['payment_id']);
    $status = trim($_POST['status']);

    // Validate status (must be either 'pending' or 'completed')
    if (!in_array($status, ['pending', 'completed'])) {
        $_SESSION['message'] = "Invalid payment status!";
        header("Location: admin_payment_manage.php");
        exit();
    }

    // Prepare and execute update query
    $update_query = "UPDATE payment SET status = ? WHERE payment_id = ?";
    $stmt = $conn->prepare($update_query);

    if ($stmt) {
        $stmt->bind_param("ss", $status, $payment_id);
        if ($stmt->execute()) {
            $_SESSION['message'] = "Payment status updated successfully.";
        } else {
            $_SESSION['message'] = "Error updating payment status.";
        }
        $stmt->close();
    } else {
        $_SESSION['message'] = "Database error: Unable to prepare statement.";
    }
} else {
    $_SESSION['message'] = "Invalid request.";
}

$conn->close();

// Redirect back
header("Location: admin_payment_manage.php");
exit();
?>
