<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all reviews with product details
$review_query = "SELECT r.id, r.product_id, p.name AS product_name, r.name, r.rating, r.comments, r.created_at 
                 FROM reviews r
                 JOIN products p ON r.product_id = p.id
                 ORDER BY r.created_at ASC";
$result = $conn->query($review_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Reviews Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 1100px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin: auto;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
            font-size: 24px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 10px;
        }
        th, td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
            font-size: 14px;
        }
        th {
            background:rgb(42, 113, 164);
            color: white;
            text-transform: uppercase;
            font-size: 14px;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .rating {
            font-size: 16px;
            font-weight: bold;
            color: #ffcc00;
        }
        @media (max-width: 768px) {
            table { width: 100%; font-size: 12px; }
            th, td { padding: 10px; }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Users Reviews Report</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>User Name</th>
                <th>Rating</th>
                <th>Comments</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td class="rating"><?php echo str_repeat("⭐", $row['rating']); ?></td>
                    <td><?php echo htmlspecialchars($row['comments']); ?></td>
                    <td><?php echo date("d M Y, H:i", strtotime($row['created_at'])); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php $conn->close(); ?>
