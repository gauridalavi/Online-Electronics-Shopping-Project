<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Fetch products, join with categories and brands
$sql = "
    SELECT p.id, p.name, p.created_at, c.name AS category_name, b.name AS brand_name
    FROM products p
    JOIN categories c ON p.category_id = c.id
    JOIN brands b ON p.brand_id = b.id
";
$products = $conn->query($sql);
?>
<?php include('./components/admin_header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Products</title>
    <link rel="stylesheet" href="css/manage_productsForm.css">

</head>
<body>
<div class="form-body">
    <div class="admin-container">
        <h1>Manage Products</h1>

        <!-- Product Table -->
        <table>
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Brand</th>
                    <th>Creation Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($product = $products->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                        <td><?php echo htmlspecialchars($product['brand_name']); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($product['created_at'])); ?></td>
                        <td class="action-buttons">
                            <!-- Edit and Delete actions -->
                            <a href="edit_product.php?id=<?php echo $product['id']; ?>">Edit</a> |
                            <a href="delete_product.php?id=<?php echo $product['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        
    </div>
    </div>
</body>
</html>
