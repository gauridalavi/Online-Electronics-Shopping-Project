<?php
include('../database/db_connect.php');

// Get search parameters
$search_status = isset($_GET['search_status']) ? $_GET['search_status'] : '';
$search_category = isset($_GET['search_category']) ? $_GET['search_category'] : '';
$search_brand = isset($_GET['search_brand']) ? $_GET['search_brand'] : '';

// SQL Query to get stock details
$sql = "SELECT 
            p.id, p.name, c.name AS category, b.name AS brand, 
            p.stock_quantity 
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        WHERE 1";

if ($search_status === 'in_stock') {
    $sql .= " AND p.stock_quantity > 0";
} elseif ($search_status === 'out_of_stock') {
    $sql .= " AND p.stock_quantity = 0";
}
if (!empty($search_category)) {
    $sql .= " AND c.name LIKE '%$search_category%'";
}
if (!empty($search_brand)) {
    $sql .= " AND b.name LIKE '%$search_brand%'";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .search-form {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .search-form select, .search-form input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 200px;
            font-size: 14px;
        }
        .search-form button {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-form button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            margin-top: 10px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: rgb(42, 113, 164);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        .status {
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            display: inline-block;
            min-width: 90px;
        }
        .in-stock {
            background-color: #28a745;
            color: white;
        }
        .out-of-stock {
            background-color: #dc3545;
            color: white;
        }
        @media (max-width: 768px) {
            table { width: 100%; font-size: 14px; }
            .search-form { flex-direction: column; align-items: center; }
            .search-form select, .search-form input, .search-form button { width: 80%; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Stock Report</h1>
        <form method="GET" class="search-form">
            <select name="search_status">
                <option value="">Filter by Stock Status</option>
                <option value="in_stock" <?php echo ($search_status == 'in_stock') ? 'selected' : ''; ?>>In Stock</option>
                <option value="out_of_stock" <?php echo ($search_status == 'out_of_stock') ? 'selected' : ''; ?>>Out of Stock</option>
            </select>
            <input type="text" name="search_category" placeholder="Search by Category" value="<?php echo htmlspecialchars($search_category); ?>">
            <input type="text" name="search_brand" placeholder="Search by Brand" value="<?php echo htmlspecialchars($search_brand); ?>">
            <button type="submit">Search</button>
        </form>

        <table border="1">
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Stock Quantity</th>
                <th>Status</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { 
                $stock_quantity = $row['stock_quantity'];

                // Determine stock status
                $stock_status = ($stock_quantity > 0) ? "<span class='status in-stock'>In Stock</span>" : "<span class='status out-of-stock'>Out of Stock</span>";
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                    <td><?php echo htmlspecialchars($row['brand']); ?></td>
                    <td><?php echo htmlspecialchars($stock_quantity); ?></td>
                    <td><?php echo $stock_status; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
