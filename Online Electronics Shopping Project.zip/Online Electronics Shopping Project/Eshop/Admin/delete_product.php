<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check if an ID is passed
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Delete the product
    $sql = "DELETE FROM products WHERE id = $product_id";
    if ($conn->query($sql) === TRUE) {
        echo "Product deleted successfully.";
    } else {
        echo "Error deleting product: " . $conn->error;
    }
}

// Redirect to the manage products page
header('Location: manage_products.php');
exit;
?>
