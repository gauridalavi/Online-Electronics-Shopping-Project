<?php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$payment_query = "SELECT p.*, o.full_name, o.email 
                  FROM payment p
                  JOIN orders o ON p.order_id = o.id
                  ORDER BY p.order_id ASC";  // Order by Order ID in ascending order

$result = $conn->query($payment_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 95%;
            max-width: 1200px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        th {
            background: #007BFF;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Status Styling */
        .status {
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: bold;
            text-transform: capitalize;
        }

        .completed {
            background: green;
            color: white;
        }

        .pending {
            background: orange;
            color: white;
        }

        /* Button Styling */
        .update-btn {
            background: #28a745;
            color: white;
            border: none;
            padding: 6px 12px;
            cursor: pointer;
            border-radius: 4px;
            transition: 0.3s;
            font-size: 14px;
        }

        .update-btn:hover {
            background: #218838;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
            text-align: center;
        }

        .close-btn {
            float: right;
            font-size: 22px;
            cursor: pointer;
        }

        /* Modal Form Styling */
        .modal-content h3 {
            margin-bottom: 10px;
            color: #333;
        }

        .modal-content label {
            display: block;
            font-weight: bold;
            margin: 10px 0 5px;
        }

        .modal-content select {
            width: 100%;
            padding: 4px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Update Button inside Modal */
        .modal-content button {
            background: #007BFF;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            transition: 0.3s;
        }

        .modal-content button:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Payment Management</h2>
    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Payment Method</th>
                <th>Payment ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['order_id']; ?></td>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo strtoupper($row['payment_method']); ?></td>
                    <td><?php echo $row['payment_id']; ?></td>
                    <td>₹<?php echo number_format($row['amount'], 2); ?></td>
                    <td>
    <span class="status 
        <?php 
            if ($row['status'] == 'completed') {
                echo 'completed';
            } elseif ($row['payment_method'] == 'cod' && $row['status'] == 'pending') {
                echo 'pending';
            } elseif ($row['payment_method'] == 'online' && $row['status'] == 'pending') {
                echo 'pending';
            } else {
                echo 'completed';
            }
        ?>">
        <?php echo ucfirst($row['status']); ?>
    </span>
</td>

                    <td><?php echo $row['created_at']; ?></td>
                    <td>
                        <?php if ($row['payment_method'] == 'cod') { ?>
                            <button class="update-btn" onclick="openModal('<?php echo $row['payment_id']; ?>')">Update</button>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div id="updateModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal()">&times;</span>
        <h3>Update Payment Status</h3>
        <form id="updateForm" method="post" action="update_payment.php">
            <input type="hidden" id="payment_id" name="payment_id">
            <label>Status:</label>
            <select name="status">
                <option value="pending">Pending</option>
                <option value="completed">Completed</option>
            </select>
            <button type="submit">Update</button>
        </form>
    </div>
</div>

<script>
function openModal(paymentId) {
    document.getElementById("payment_id").value = paymentId;
    document.getElementById("updateModal").style.display = "block";
}

function closeModal() {
    document.getElementById("updateModal").style.display = "none";
}

// Close the modal when clicking outside
window.onclick = function(event) {
    let modal = document.getElementById("updateModal");
    if (event.target == modal) {
        modal.style.display = "none";
    }
};
</script>

</body>
</html>

<?php $conn->close(); ?> 
