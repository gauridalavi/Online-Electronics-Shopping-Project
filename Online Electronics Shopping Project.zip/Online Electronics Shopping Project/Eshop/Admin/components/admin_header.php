<?php

// Check if a session is not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// Check if the admin is logged in
if (!isset($_SESSION['admin_username'])) {
    // Redirect to login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/dashbord.css">
    <style>
        /* Dropdown container */
        .dropdown-container {
            position: relative;
            display: inline-block;
        }

        /* Main dropdown */
        .dropdown-menu {
            display: none;
            position: absolute;
            background: white;
            min-width: 180px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            overflow: hidden;
            z-index: 100;
        }

        .dropdown-menu a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: black;
            border-bottom: 1px solid #ddd;
        }

        .dropdown-menu a:hover {
            background: #f1f1f1;
        }

        /* Show dropdown when active */
        .dropdown-container.active .dropdown-menu {
            display: block;
        }

        /* Orders Report sub-dropdown */
        .sub-dropdown {
            position: relative;
        }

        .sub-dropdown-menu {
            display: none;
            background: white;
            min-width: 180px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            overflow: hidden;
            margin-left: 15px;
        }

        .sub-dropdown.active .sub-dropdown-menu {
            display: block;
        }

        .sub-dropdown a {
            padding: 10px;
            display: block;
            text-decoration: none;
            color: black;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="logo">Admin<span>Panel</span></div>
        <nav class="nav">
            <a href="./admin-dashboard.php">Home</a>
            <a href="./add_products.php">Products</a>
            <a href="./admin_orders.php">Orders</a>
            <a href="./users_managment.php">Users</a>
            <a href="./admin_messages.php">Messages</a>

            <!-- Report Dropdown -->
            <div class="dropdown-container">
                <a href="#" class="dropdown-toggle">Reports ▼</a>
                <div class="dropdown-menu">
                    <a href="./users_report.php">Users Report</a>
                    <a href="./admin_payment_reports.php">Payment Report</a>
                    <a href="./stock_report.php">Stock Report</a>
                    <a href="./customers_reviews_report.php">Reviews Report</a>

                   <div class="sub-dropdown">
                        <a href="#" class="orders-toggle">Orders Report ▼</a>
                        <div class="sub-dropdown-menu">
                            <a href="./pending_orders.php">Pending Orders</a>
                            <a href="./processing_orders.php">processing Orders</a>
                            <a href="./shipped_orders.php">shipped Orders</a>
                            <a href="./delivered_orders.php">Delivered Orders</a>
                            <a href="./cancelled_orders.php">Cancelled Orders</a>

                        </div>
                        
                </div>
            </div>
        </nav>

        <div class="user-menu">
            <div class="user-icon"></div>
            <div class="dropdown">
                <div class="dropdown-header"><?php echo $_SESSION['admin_username']; ?></div>
                <a href="./update-profile.php" class="dropdown-btn btn-update">Update Profile</a>
                <a href="./admin_logout.php" class="dropdown-btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Report Dropdown Toggle
            const reportDropdown = document.querySelector('.dropdown-container');
            const reportToggle = document.querySelector('.dropdown-toggle');

            reportToggle.addEventListener('click', (e) => {
                e.preventDefault();
                reportDropdown.classList.toggle('active');
            });

            // Orders Report Sub-Dropdown Toggle
            const ordersDropdown = document.querySelector('.sub-dropdown');
            const ordersToggle = document.querySelector('.orders-toggle');

            ordersToggle.addEventListener('click', (e) => {
                e.preventDefault();
                ordersDropdown.classList.toggle('active');
            });

            // Close dropdown if clicked outside
            document.addEventListener('click', (e) => {
                if (!reportDropdown.contains(e.target)) {
                    reportDropdown.classList.remove('active');
                    ordersDropdown.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
