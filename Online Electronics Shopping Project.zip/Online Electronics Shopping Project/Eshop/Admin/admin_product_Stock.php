<?php
include('../database/db_connect.php'); // Database connection file

// Get search parameters
$search_name = isset($_GET['search_name']) ? $_GET['search_name'] : '';
$search_category = isset($_GET['search_category']) ? $_GET['search_category'] : '';
$search_brand = isset($_GET['search_brand']) ? $_GET['search_brand'] : '';

// SQL Query to get stock details
$query = "SELECT 
            p.id, p.name, c.name AS category, b.name AS brand, 
            p.stock_quantity, 
            COALESCE((SELECT SUM(oi.quantity) FROM order_items oi WHERE oi.product_id = p.id), 0) AS total_sold
          FROM products p
          LEFT JOIN categories c ON p.category_id = c.id
          LEFT JOIN brands b ON p.brand_id = b.id
          WHERE 1";

if (!empty($search_name)) {
    $query .= " AND p.name LIKE '%$search_name%'";
}
if (!empty($search_category)) {
    $query .= " AND c.name LIKE '%$search_category%'";
}
if (!empty($search_brand)) {
    $query .= " AND b.name LIKE '%$search_brand%'";
}

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Product Stock Management</title>
    <style>
        .form-body { text-align: center; padding: 20px; }
        table { width: 80%; margin: 20px auto; border-collapse: collapse; background: #fff; }
        th, td { padding: 12px; border-bottom: 1px solid #ddd; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:hover { background-color: #f1f1f1; }
        .search-form {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .search-form input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 200px;
        }
        .search-form button {
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .search-form button:hover {
            background-color: #0056b3;
        }
        .stock-info {
            font-size: 18px;
            font-weight: bold;
            color: #28a745;
            margin-top: 10px;
        }
        @media (max-width: 768px) {
            table { width: 100%; }
            th, td { padding: 10px; font-size: 14px; }
        }
    </style>
</head>
<body>
    <div class="form-body">
        <h1>Product Stock Management</h1>
        <form method="GET" class="search-form">
            <input type="text" name="search_name" placeholder="Search by Product Name" value="<?php echo htmlspecialchars($search_name); ?>">
            <input type="text" name="search_category" placeholder="Search by Category" value="<?php echo htmlspecialchars($search_category); ?>">
            <input type="text" name="search_brand" placeholder="Search by Brand" value="<?php echo htmlspecialchars($search_brand); ?>">
            <button type="submit">Search</button>
        </form>

        <table border="1">
            <tr>
                <th>ID</th>
                <th>Product Name</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Original Stock</th>
                <th>Total Sold</th>
                <th>Remaining Stock</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { 
                $total_sold = $row['total_sold']; // Sales from order_items table
                $original_stock = $row['stock_quantity']; // Current stock in products table
                $remaining_stock = max($original_stock - $total_sold, 0); // Ensure no negative values
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                    <td><?php echo htmlspecialchars($row['brand']); ?></td>
                    <td><?php echo htmlspecialchars($original_stock); ?></td>
                    <td><?php echo htmlspecialchars($total_sold); ?></td>
                    <td><?php echo htmlspecialchars($remaining_stock); ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
