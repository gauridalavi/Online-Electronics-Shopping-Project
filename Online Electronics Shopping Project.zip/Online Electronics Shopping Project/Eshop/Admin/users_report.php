<?php
session_start();
$conn = new mysqli("localhost", "root", "", "eshop");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if admin is logged in
if (!isset($_SESSION["admin_id"])) {
    die("Access Denied. <a href='admin_login.php'>Login</a>");
}

// Fetch all users from the database, including the registration date
$sql = "SELECT id, username, email, created_at FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Registration Report</title>
<style>
    /* General Styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 90%;
        max-width: 800px;
        margin: 40px auto;
        background: white;
        padding: 20px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        text-align: center;
    }

    /* Table Styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background: white;
    }

    thead {
        background-color: rgb(42, 113, 164);
        color: white;
    }

    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tbody tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tbody tr:hover {
        background-color: #e9ecef;
    }

    /* Responsive Design */
    @media (max-width: 600px) {
        table, th, td {
            font-size: 14px;
        }

        .container {
            width: 95%;
        }
    }
</style>
</head>
<body>

<div class="container">
    <h2>Users Registration Report</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Registration Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row["id"] ?></td>
                    <td><?= $row["username"] ?></td>
                    <td><?= $row["email"] ?></td>
                    <td><?= date("Y-m-d H:i:s", strtotime($row["created_at"])) ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

</div>

</body>
</html>
