<?php
// Start session (if admin authentication is used)
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "eshop");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch messages from the database with LEFT JOIN
$sql = "SELECT messages.id, 
               COALESCE(users.username, 'Unknown User') AS username, 
               messages.email, 
               messages.number, 
               messages.message,
               messages.date
        FROM messages 
        LEFT JOIN users ON messages.user_id = users.id
        ORDER BY messages.id ASC";


$result = $conn->query($sql);

include('./components/admin_header.php'); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Messages</title>
    <style>
        .form-body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
            margin: 0;
        }
        .container {
            max-width: 1100px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin: auto;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
            font-size: 24px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 10px;
        }
        th, td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
            font-size: 14px;
        }
        th {
            background: rgb(42, 113, 164);
            color: white;
            text-transform: uppercase;
            font-size: 14px;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .delete-btn {
            color: red;
            text-decoration: none;
            font-weight: bold;
        }
        .delete-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="form-body">
        <br>
        <div class="container">
            <h2>User Messages</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                        <td>" . htmlspecialchars($row['id']) . "</td>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>" . htmlspecialchars($row['email']) . "</td>
                        <td>" . htmlspecialchars($row['number']) . "</td>
                        <td>" . nl2br(htmlspecialchars($row['message'])) . "</td>
                        <td>" . htmlspecialchars($row['date']) . "</td> <!-- New Date Column -->
                        <td><a href='delete_messages.php?id=" . htmlspecialchars($row['id']) . "' class='delete-btn' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>
                      </tr>";
                
                    }
                } else {
                    echo "<tr><td colspan='6'>No messages found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>
