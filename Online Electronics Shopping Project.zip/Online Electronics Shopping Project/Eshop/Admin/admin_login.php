<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT id, username, password FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the user data
        $row = $result->fetch_assoc();
        
        // Verify the password
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin_id'] = $row['id'];  // ✅ Store Admin ID
            $_SESSION['admin_username'] = $row['username'];

            header("Location: admin-dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid Username or Password');</script>";
        }
    } else {
        echo "<script>alert('Invalid Username or Password');</script>";
    }

    $stmt->close();
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f5f5f5;
        }

        .login-card {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            border: 1px solid #ddd;
            width: 90%;
            max-width: 400px;
        }

        .login-title {
            text-align: center;
            color: #333;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        .default-creds {
            text-align: center;
            color: #666;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }

        .default-creds .username {
            color: #F39C12;
        }

        .default-creds .password {
            color: #F39C12;
        }

        .input-field {
            width: 100%;
            padding: 0.8rem;
            margin-bottom: 1rem;
            border: none;
            border-radius: 4px;
            background-color: #f7f7f7;
            font-size: 1rem;
        }

        .input-field:focus {
            outline: 2px solid #2E86C1;
            background-color: white;
        }

        .login-btn {
            width: 100%;
            padding: 0.8rem;
            background: #2E86C1;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
        }

        .login-btn:hover {
            background: #2874A6;
        }

        @media (max-width: 480px) {
            .login-card {
                width: 95%;
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1 class="login-title">LOGIN NOW</h1>
       
        <form action="" method="POST">
            <input 
                type="text" 
                name="username"
                class="input-field" 
                placeholder="enter your username"
                required
            >
            <input 
                type="password" 
                name="password"
                class="input-field" 
                placeholder="enter your password"
                required
            >
            <button type="submit" class="login-btn">Login Now</button>
        </form>
    </div>
</body>
</html>