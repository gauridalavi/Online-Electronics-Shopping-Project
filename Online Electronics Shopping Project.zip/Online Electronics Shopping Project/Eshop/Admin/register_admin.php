<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve submitted form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate inputs
    if (empty($username) || empty($password) || empty($confirm_password)) {
        echo "<script>alert('All fields are required');</script>";
    } elseif ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        // Check if username already exists
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Username already exists');</script>";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert new admin into the database
            $stmt = $conn->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hashed_password);

            if ($stmt->execute()) {
                echo "<script>alert('Registration successful');</script>";
                // Redirect to login page or dashboard
                header("Location: admin_login.php");
                exit();
            } else {
                echo "<script>alert('Error during registration');</script>";
            }
        }
        $stmt->close();
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f5f5f5;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
        }

        .logo span {
            color: #2E86C1;
        }

        .nav {
            display: flex;
            gap: 2rem;
        }

        .nav a {
            text-decoration: none;
            color: #333;
        }

        .user-icon {
            width: 35px;
            height: 35px;
            background: #2E86C1;
            border-radius: 50%;
            position: relative;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .user-icon::before {
            content: '';
            position: absolute;
            top: 25%;
            left: 50%;
            transform: translateX(-50%);
            width: 14px;
            height: 14px;
            background: white;
            border-radius: 50%;
        }

        .user-icon::after {
            content: '';
            position: absolute;
            bottom: 10%;
            left: 50%;
            transform: translateX(-50%);
            width: 18px;
            height: 10px;
            background: white;
            border-radius: 10px 10px 0 0;
        }

        .register-card {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            border: 1px solid #ddd;
            width: 90%;
            max-width: 400px;
            margin-top: 60px;
        }

        .register-title {
            text-align: center;
            color: #333;
            font-size: 1.5rem;
            margin-bottom: 2rem;
        }

        .input-field {
            width: 100%;
            padding: 0.8rem;
            margin-bottom: 1rem;
            border: none;
            border-radius: 4px;
            background-color: #f7f7f7;
            font-size: 1rem;
        }

        .input-field:focus {
            outline: 2px solid #2E86C1;
            background-color: white;
        }

        .register-btn {
            width: 100%;
            padding: 0.8rem;
            background: #2E86C1;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 0.5rem;
        }

        .register-btn:hover {
            background: #2874A6;
        }

        @media (max-width: 768px) {
            .nav {
                display: none;
            }
            
            .register-card {
                width: 95%;
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
   
    <header class="header">
        <div class="logo">Admin<span>Panel</span></div>
        <nav class="nav">
            <a href="#home">home</a>
            <a href="#products">products</a>
            <a href="#orders">orders</a>
            <a href="#users">users</a>
            <a href="#messages">messages</a>
        </nav>
        <div class="user-icon"></div>
    </header>

    <div class="register-card">
        <h1 class="register-title">REGISTER NOW</h1>
        <form method="POST">
            <input 
                type="text" 
                class="input-field" 
                name="username"
                placeholder="Enter your username"
                required
            >
            <input 
                type="password" 
                class="input-field" 
                name="password"
                placeholder="Enter your password"
                required
            >
            <input 
                type="password" 
                class="input-field" 
                name="confirm_password"
                placeholder="Confirm your password"
                required
            >
            <button type="submit" class="register-btn">Register Now</button>
        </form>
    </div>
</body>
</html>
