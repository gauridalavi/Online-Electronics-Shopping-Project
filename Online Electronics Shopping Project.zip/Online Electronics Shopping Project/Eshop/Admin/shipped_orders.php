<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch only Pending orders and join with products table to get product images
$sql = "SELECT orders.id, orders.order_date, orders.full_name, orders.email, orders.phone_no, orders.shipping_address, 
                orders.payment_method, orders.total_price, orders.status, 
                GROUP_CONCAT(products.image_main SEPARATOR ', ') AS product_images
        FROM orders
        JOIN order_items ON orders.id = order_items.order_id
        JOIN products ON order_items.product_id = products.id
        WHERE orders.status = 'Shipped'
        GROUP BY orders.id";

$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipped Orders Report</title>
    <link rel="stylesheet" href="css/manage_ordersForm.css">
</head>
<body>
    <h2>Shipped Orders Report</h2>
    <table border="1">
        <tr>
            <th>Order ID</th>
            <th>Date</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Product</th>
            <th>Shipping Address</th>
            <th>Payment</th>
            <th>Total Price</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['id']); ?></td>
            <td><?php echo htmlspecialchars($row['order_date']); ?></td>
            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td>
                <?php 
                echo isset($row['phone_no']) ? htmlspecialchars($row['phone_no']) : "N/A"; 
                ?>
            </td>
            <td>
            <?php 
                if (!empty($row['product_images'])) {
                    $productImages = explode(", ", $row['product_images']);
                    foreach ($productImages as $image) {
                        echo '<img src="' . htmlspecialchars($image) . '" alt="Product" class="product-image">';
                    }
                } else {
                    echo 'No image available';
                }
                ?>
            </td>
            <td><?php echo htmlspecialchars($row['shipping_address']); ?></td>
            <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
            <td>₹<?php echo number_format($row['total_price'], 2); ?></td>
            <td><?php echo htmlspecialchars($row['status']); ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
