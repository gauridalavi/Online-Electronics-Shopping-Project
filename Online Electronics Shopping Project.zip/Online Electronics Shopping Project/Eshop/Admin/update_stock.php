<?php
include('../database/db_connect.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $product = $conn->query("SELECT * FROM products WHERE id = $id")->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin -update stock</title>
    
<style>
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
    text-align: center;
}

/* Update Stock Form Container */
form {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    width: 50%;
    margin: 30px auto;
    text-align: left;
}

form h2 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}

/* Form Elements */
label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
    color: #555;
}

input[type="text"],
input[type="number"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    background-color: #f9f9f9;
}

input[type="text"]:disabled {
    background-color: #e0e0e0;
}

/* Button Styles */
button[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #007bff;
    border: none;
    color: white;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}

/* Responsive Design */
@media (max-width: 768px) {
    form {
        width: 80%;
    }

    input[type="text"],
    input[type="number"],
    button[type="submit"] {
        font-size: 14px;
    }
}
</style>
</head>
<body>
<form action="process_update_stock.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
    <label>Product Name:</label>
    <input type="text" value="<?php echo $product['name']; ?>" disabled>

    <label>Current Stock:</label>
    <input type="number" name="stock_quantity" value="<?php echo $product['stock_quantity']; ?>" required>

    <button type="submit">Update Stock</button>
</form>
</body>
</html>
