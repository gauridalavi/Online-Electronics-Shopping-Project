<?php
include('../database/db_connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $stock_quantity = $_POST['stock_quantity'];

    $sql = "UPDATE products SET stock_quantity = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $stock_quantity, $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Stock updated successfully!";
    } else {
        echo "No changes made.";
    }

    $stmt->close();
    $conn->close();
}
?>
