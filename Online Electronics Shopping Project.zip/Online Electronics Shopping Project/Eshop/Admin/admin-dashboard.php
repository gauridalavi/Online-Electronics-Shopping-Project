<?php
// Start the session
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin_username'])) {
    // Redirect to login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$ordersPlaced = 0;
$productsAdded = 0;
$normalUsers = 0;
$newMessages = 0;
$usersFeedbacks = 0;


// Fetch total pendings

// Fetch orders placed
$result = $conn->query("SELECT COUNT(*) AS ordersPlaced FROM orders");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $ordersPlaced = $row['ordersPlaced'] ?? 0;
}

// Fetch products added
$result = $conn->query("SELECT COUNT(*) AS productsAdded FROM products");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $productsAdded = $row['productsAdded'] ?? 0;
}

// Fetch normal users
$result = $conn->query("SELECT COUNT(*) AS normalUsers FROM users");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $normalUsers = $row['normalUsers'] ?? 0;
}


// Fetch normal users
$result = $conn->query("SELECT COUNT(*) AS managePay FROM payment");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $managePay = $row['managePay'] ?? 0;
}

// Fetch new messages
$result = $conn->query("SELECT COUNT(*) AS newMessages FROM messages");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $newMessages = $row['newMessages'] ?? 0;
}

// Fetch new messages
$result = $conn->query("SELECT COUNT(*) AS usersReviews FROM reviews");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $usersReviews = $row['usersReviews'] ?? 0;
}

// Close the connection
$conn->close();
?>
<?php include('./components/admin_header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/dashbord.css">
</head>
<body>
    

    <h1 class="dashboard-title">DASHBOARD</h1>

    <div class="dashboard-grid">
        <div class="card">
            <h2 class="card-title">Welcome!</h2>
            <p class="card-subtitle"><?php echo $_SESSION['admin_username']; ?></p>
            <a href="update-profile.php" class="btn">Update Profile</a>

        </div>

        <div class="card">
            <h2 class="card-title"><?php echo $productsAdded; ?></h2>
            <p class="card-subtitle">Products Added</p>
            <a href="add_products.php" class="btn">Insert  Products</a>
        </div>

        <div class="card">
            <h2 class="card-title"><?php echo $productsAdded; ?></h2>
            <p class="card-subtitle">Manage Products</p>
            <a href="manage_products.php" class="btn">See  Products</a>
        </div>

        <div class="card">
            <h2 class="card-title"><?php echo $productsAdded; ?></h2>
            <p class="card-subtitle"> Products Stock</p>
         <a href="admin_product_stock.php" class="btn">See Stock</a><br>
        </div>


        <div class="card">
            <h2 class="card-title"><?php echo $ordersPlaced; ?></h2>
            <p class="card-subtitle">Orders Placed</p>
            <a href="admin_orders.php" class="btn">See Orders</a>
            </div>



        <div class="card">
            <h2 class="card-title"><?php echo $normalUsers; ?></h2>
            <p class="card-subtitle">Normal Users</p>
             <a href="users_managment.php" class="btn">See Users</a>
            </div>

            <div class="card">
            <h2 class="card-title"><?php echo $managePay; ?></h2>
            <p class="card-subtitle">Manage Payments</p>
             <a href="admin_payment_manage.php" class="btn">See payments</a>
            </div>

        <div class="card">
            <h2 class="card-title"><?php echo $newMessages; ?></h2>
            <p class="card-subtitle">New Messages</p>
              <a href="admin_messages.php" class="btn">See Messages</a><br>
            </div>

            
        <div class="card">
            <h2 class="card-title"><?php echo $usersReviews; ?></h2>
            <p class="card-subtitle">New feedbacks</p>
              <a href="admin_feedback.php" class="btn">See feedbacks</a><br>
            </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const userMenu = document.querySelector('.user-menu');
        const dropdown = document.querySelector('.dropdown');

        userMenu.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevents closing when clicking inside the menu
            userMenu.classList.toggle('active');
        });

        // Close the dropdown if clicked outside
        document.addEventListener('click', (e) => {
            if (!userMenu.contains(e.target)) {
                userMenu.classList.remove('active');
            }
        });
    });
</script>



</body>
</html>
