<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check if the 'id' parameter is passed in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Product ID is missing.");
}

$product_id = $_GET['id']; // Get the product ID from the URL

// Fetch the product to edit from the database
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $product_id);
$stmt->execute();
$product_result = $stmt->get_result();

if ($product_result->num_rows == 0) {
    die("Product not found.");
}

$product = $product_result->fetch_assoc();

// Fetch categories and brands for the dropdowns
$categories = $conn->query("SELECT * FROM categories");
$brands = $conn->query("SELECT * FROM brands");

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $product_name = $_POST['product_name'];
    $description = $_POST['description'];
    $category_id = $_POST['category_id'];
    $brand_id = $_POST['brand_id'];
    $price = $_POST['price'];
    $original_price = $_POST['original_price'];
    $discount = $_POST['discount'];
    $stock_quantity = $_POST['stock_quantity']; // Get stock quantity

    // Define product folder path
    $product_folder = 'uploads/productImages/' . $product_id . '/';

    // Initialize image variables
    $image_main = $product['image_main'];
    $image_thumb1 = $product['image_thumb1'];
    $image_thumb2 = $product['image_thumb2'];

    // Handle image removals and uploads
    if (isset($_POST['remove_main_image'])) {
        if (!empty($product['image_main']) && file_exists($product['image_main'])) {
            unlink($product['image_main']); // Remove old image
        }
        $image_main = ''; // Clear image path in DB
    }

    if (isset($_FILES['image_main']) && $_FILES['image_main']['error'] == 0) {
        $image_main = $product_folder . basename($_FILES['image_main']['name']);
        move_uploaded_file($_FILES['image_main']['tmp_name'], $image_main);
    }

    if (isset($_POST['remove_thumb1_image'])) {
        if (!empty($product['image_thumb1']) && file_exists($product['image_thumb1'])) {
            unlink($product['image_thumb1']);
        }
        $image_thumb1 = '';
    }

    if (isset($_FILES['image_thumb1']) && $_FILES['image_thumb1']['error'] == 0) {
        $image_thumb1 = $product_folder . basename($_FILES['image_thumb1']['name']);
        move_uploaded_file($_FILES['image_thumb1']['tmp_name'], $image_thumb1);
    }

    if (isset($_POST['remove_thumb2_image'])) {
        if (!empty($product['image_thumb2']) && file_exists($product['image_thumb2'])) {
            unlink($product['image_thumb2']);
        }
        $image_thumb2 = '';
    }

    if (isset($_FILES['image_thumb2']) && $_FILES['image_thumb2']['error'] == 0) {
        $image_thumb2 = $product_folder . basename($_FILES['image_thumb2']['name']);
        move_uploaded_file($_FILES['image_thumb2']['tmp_name'], $image_thumb2);
    }

    // Update product in the database
    $sql = "UPDATE products SET
            name = ?, description = ?, category_id = ?, brand_id = ?, price = ?, original_price = ?, discount = ?, stock_quantity = ?,
            image_main = ?, image_thumb1 = ?, image_thumb2 = ?
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssiiddissssi',
        $product_name, $description, $category_id, $brand_id, $price, $original_price, $discount, $stock_quantity,
        $image_main, $image_thumb1, $image_thumb2, $product_id
    );

    if ($stmt->execute()) {
        $success_message = "Product updated successfully!";
    } else {
        $error_message = "Failed to update product: " . $conn->error;
    }

    $stmt->close();
}
// Close database connection
?>
<?php include('./components/admin_header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link rel="stylesheet" href="css/edit_productForm.css">
</head>
<body>
<div class="form-body">
<div class="admin-container">
    <h1>Edit Product</h1>

    <?php if (isset($success_message)) { ?>
        <div class="message success"><?php echo $success_message; ?></div>
    <?php } elseif (isset($error_message)) { ?>
        <div class="message error"><?php echo $error_message; ?></div>
    <?php } ?>

    <form action="edit_product.php?id=<?php echo $product['id']; ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">

        <label for="product_name">Product Name:</label>
        <input type="text" name="product_name" value="<?php echo htmlspecialchars($product['name']); ?>" required>

        <label for="description">Description:</label>
        <textarea name="description" rows="4" required><?php echo htmlspecialchars($product['description']); ?></textarea>

        <label for="category_id">Category:</label>
        <select name="category_id" required>
            <?php while ($category = $categories->fetch_assoc()) { ?>
                <option value="<?php echo $category['id']; ?>" <?php echo ($category['id'] == $product['category_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($category['name']); ?>
                </option>
            <?php } ?>
        </select>

        <label for="brand_id">Brand:</label>
        <select name="brand_id" required>
            <?php while ($brand = $brands->fetch_assoc()) { ?>
                <option value="<?php echo $brand['id']; ?>" <?php echo ($brand['id'] == $product['brand_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($brand['name']); ?>
                </option>
            <?php } ?>
        </select>

        <label for="stock_quantity">Stock Quantity:</label>
        <input type="number" name="stock_quantity" value="<?php echo $product['stock_quantity']; ?>" required>

        <label for="image_main">Main Image:</label>
        <?php if (!empty($product['image_main'])): ?>
            <div>
                <img src="<?php echo $product['image_main']; ?>" alt="Main Image" width="100">
                <input type="checkbox" name="remove_main_image" value="1"> Remove this image
            </div>
        <?php endif; ?>
        <input type="file" name="image_main">

        <label for="image_thumb1">Thumbnail 1:</label>
        <?php if (!empty($product['image_thumb1'])): ?>
            <div>
                <img src="<?php echo $product['image_thumb1']; ?>" alt="Thumbnail 1" width="100">
                <input type="checkbox" name="remove_thumb1_image" value="1"> Remove this image
            </div>
        <?php endif; ?>
        <input type="file" name="image_thumb1">

        <label for="image_thumb2">Thumbnail 2:</label>
        <?php if (!empty($product['image_thumb2'])): ?>
            <div>
                <img src="<?php echo $product['image_thumb2']; ?>" alt="Thumbnail 2" width="100">
                <input type="checkbox" name="remove_thumb2_image" value="1"> Remove this image
            </div>
        <?php endif; ?>
        <input type="file" name="image_thumb2">

        <label for="price">Price (₹):</label>
        <input type="number" name="price" value="<?php echo $product['price']; ?>" required>

        <label for="original_price">Original Price (₹):</label>
        <input type="number" name="original_price" value="<?php echo $product['original_price']; ?>">

        <label for="discount">Discount (%):</label>
        <input type="number" name="discount" value="<?php echo $product['discount']; ?>" step="0.01">

        <button type="submit" class="btn">Update Product</button>
    </form>
</div>
</div>
</body>
</html>
