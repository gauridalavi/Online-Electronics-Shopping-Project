
        const signupForm = document.getElementById('signupForm');

        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            // Store user data in localStorage (in a real app, this would be sent to a server)
            localStorage.setItem('registered_username', username);
            localStorage.setItem('registered_email', email);
            localStorage.setItem('registered_password', password);

            alert('Registration successful! Please login.');
            window.location.href = 'login.php';
        });