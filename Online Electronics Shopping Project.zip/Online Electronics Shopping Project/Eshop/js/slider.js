
const slider = document.querySelector('.slider');
const dots = document.querySelectorAll('.dot');
let currentIndex = 0;
const totalSlides = dots.length;

function goToSlide(index) {
    slider.style.transform = `translateX(-${index * 100}%)`; // Move slider to the correct slide
    dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === index); // Highlight the active dot
    });
    currentIndex = index; // Update the current index
}

dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
        clearInterval(autoSlideInterval); // Stop auto-slide temporarily when manual interaction happens
        goToSlide(index);
        autoSlideInterval = setInterval(autoSlide, 5000); // Restart auto-slide
    });
});

// Auto-slide functionality
function autoSlide() {
    currentIndex = (currentIndex + 1) % totalSlides; // Loop back to the first slide
    goToSlide(currentIndex);
}

// Start auto-slide
let autoSlideInterval = setInterval(autoSlide, 5000); // Change slide every 5 seconds