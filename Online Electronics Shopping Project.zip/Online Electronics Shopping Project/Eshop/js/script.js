// script.js

// Check if user is logged in and show/hide login dropdown
document.addEventListener("DOMContentLoaded", function () {
  const loginBtn = document.getElementById("login-btn");
  const loginDropdown = document.getElementById("login-dropdown");
  
  if (loginBtn) {
      loginBtn.addEventListener("click", function (event) {
          event.stopPropagation();
          loginDropdown.classList.toggle("hidden");
      });
  }
  
  document.addEventListener("click", function () {
      loginDropdown.classList.add("hidden");
  });
});

// Update cart count dynamically using AJAX
function updateCartCount() {
  fetch("update_cart.php")
      .then(response => response.json())
      .then(data => {
          document.getElementById("cart-count").innerText = data.count;
      })
      .catch(error => console.error("Error fetching cart count:", error));
}

// Toggle category menu
document.addEventListener("DOMContentLoaded", function () {
  const categoryBtn = document.getElementById("category-btn");
  const categoryMenu = document.getElementById("category-menu");
  
  if (categoryBtn) {
      categoryBtn.addEventListener("click", function () {
          categoryMenu.classList.toggle("hidden");
      });
  }
});

