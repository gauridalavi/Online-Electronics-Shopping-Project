<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$order_id = $_POST['order_id'] ?? null;
if (!$order_id) {
    die("Invalid order.");
}

// Update order status to "Cancelled"
$sql = "UPDATE orders SET status = 'Cancelled' WHERE id = ? AND status = 'Pending'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();

header("Location: order_history.php");
exit();
?>
