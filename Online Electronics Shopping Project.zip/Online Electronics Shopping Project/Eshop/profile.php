<?php
session_start();
include('database/db_connect.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user profile details
$query = $conn->prepare("SELECT u.email, p.first_name, p.phone, p.address, p.city, p.state, p.zip 
                         FROM users u 
                         LEFT JOIN userprofile p ON u.id = p.user_id 
                         WHERE u.id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

// If user profile doesn't exist, create an empty one
if (!$user || empty($user['first_name'])) {
    $insertProfile = $conn->prepare("INSERT INTO userprofile (user_id, first_name, phone, address, city, state, zip) 
                                     VALUES (?, '', '', '', '', '', '') 
                                     ON DUPLICATE KEY UPDATE user_id = VALUES(user_id)");
    $insertProfile->bind_param("i", $user_id);
    $insertProfile->execute();

    // Fetch again after insert
    $query->execute();
    $result = $query->get_result();
    $user = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="css/profile.css" rel="stylesheet">
    <link href="css/footer.css" rel="stylesheet">

</head>
<body>
<div class="form-body">
<div class="container">
    <div class="sidebar">
        <div class="user-info">
            <div class="avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="greeting">Hello, <?php echo htmlspecialchars($user['first_name'] ?? 'User'); ?></div>
        </div>
        <nav>
            <a href="profile.php" class="nav-item active"><i class="fas fa-user-circle"></i> Personal Information</a>
            <a href="change_password.php" class="nav-item"><i class="fas fa-lock"></i> Change Password</a>
            <a href="order_history.php" class="nav-item" data-page="orders">
                    <i class="fas fa-shopping-bag"></i> MY ORDERS
                </a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="page">
            <h2><i class="fas fa-user"></i> Personal Information</h2>
            <form id="profileForm">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> First Name</label>
                    <input type="text" id="first_name" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> Mobile Number</label>
                    <input type="text" id="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-map-marker-alt"></i> Address</label>
                    <input type="text" id="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-city"></i> City</label>
                    <input type="text" id="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-flag"></i> State</label>
                    <input type="text" id="state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-mail-bulk"></i> Zip Code</label>
                    <input type="text" id="zip" value="<?php echo htmlspecialchars($user['zip'] ?? ''); ?>">
                </div>
                <button type="submit" class="save-btn"><i class="fas fa-save"></i> Update</button>
            </form>
        </div>
    </div>
</div>
</div>
<script>
document.getElementById("profileForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    let userData = {
        first_name: document.getElementById("first_name").value,
        phone: document.getElementById("phone").value,
        address: document.getElementById("address").value,
        city: document.getElementById("city").value,
        state: document.getElementById("state").value,
        zip: document.getElementById("zip").value
    };

    let response = await fetch("update_profile.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData)
    });

    let result = await response.json();

    if (result.success) {
        alert("Profile updated successfully!");
        window.location.reload();  // Reload to reflect changes
    } else {
        alert("Error updating profile: " + result.error);
    }
});


</script>
<?php include('./components/footer.php'); ?>

</body>
</html>
