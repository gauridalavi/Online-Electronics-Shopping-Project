<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Store customer details in session
    $_SESSION['customer_details'] = [
        'name' => $_POST['fullName'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'address' => $_POST['address'],
        'city' => $_POST['city'],
        'state' => $_POST['state'],
        'zip' => $_POST['zip']
    ];

    // Store the total price in session
    $_SESSION['total_price'] = $_POST['total_price'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'eshop');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the user_id from session
    $user_id = $_SESSION['user_id'];

    // Fetch cart items for the logged-in user from the cart table
    $sql = "SELECT * FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Store cart items in session
    $_SESSION['cart_items'] = $cart_items;

    // Redirect to the payment page
    header("Location: payment.php");
    exit();
} else {
    // Handle invalid request
    echo "Invalid request.";
    exit();
}
?>
