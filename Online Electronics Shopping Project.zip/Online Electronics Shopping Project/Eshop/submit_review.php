<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Check if the user is logged in
// Check if the user is logged in
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    // Redirect to login page with return URL
    header("Location: login.php?return=submit_review.php");
    exit();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Debugging: Print received POST data
    
    // Get form data safely
    $name = isset($_POST['name']) ? mysqli_real_escape_string($conn, $_POST['name']) : '';
    $rating = isset($_POST['rating']) ? (int) $_POST['rating'] : 0;
    $comments = isset($_POST['comments']) ? mysqli_real_escape_string($conn, $_POST['comments']) : '';
    $product_id = isset($_POST['product_id']) ? (int) $_POST['product_id'] : 0;

    // Debugging: Check if data is correctly retrieved
    if (empty($name) || empty($comments) || $rating < 1 || $rating > 5 || $product_id <= 0) {
        die("<script>alert('Fill all fields and provide a valid rating.'); window.history.back();</script>");
    }

    // Insert into database
    $query = "INSERT INTO reviews (product_id, name, rating, comments) VALUES ('$product_id', '$name', '$rating', '$comments')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Thank you for your review!'); window.location.href = 'products_details.php?id=$product_id';</script>";
    } else {
        echo "<script>alert('Error submitting review. Try again.'); window.location.href = 'products_details.php?id=$product_id';</script>";
    }
}
?>
