<?php
// Start session

// Database connection
include('database/db_connect.php'); // Include your database connection file


// Get category and brand filters
$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;
$brand_id = isset($_GET['brand_id']) ? intval($_GET['brand_id']) : 0;

// Build query for filtering products
$query = "SELECT * FROM products WHERE 1";
if ($category_id > 0) {
    $query .= " AND category_id = $category_id";
}
if ($brand_id > 0) {
    $query .= " AND brand_id = $brand_id";
}

$products = $conn->query($query);
?>
<?php include('./components/header.php'); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/shop.css">
       
</head>
<body>
<div class="form-body">
<!-- Product Listing -->
<div class="container">
    <h1>Our Products</h1>
    <div class="product-grid">
        <?php
        if ($products->num_rows > 0) {
            while ($product = $products->fetch_assoc()) { ?>
                <div class="product-card">
                    <img src="Admin/uploads/productImages/<?php echo $product['id']; ?>/<?php echo basename($product['image_main']); ?>" 
                         alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <div class="product-details">
                        <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="price">₹<?php echo $product['price']; ?></p>
                        <a href="products_details.php?id=<?php echo $product['id']; ?>" class="view-details">View Details</a>
                    </div>
                </div>
        <?php }
        } else {
            echo "<p style='text-align: center; font-size: 18px;'>No products available.</p>";
        }
        ?>
    </div>
</div>
</div>

<script>
    function toggleMenu() {
        const menu = document.getElementById('category-menu');
        const button = document.querySelector('.navbar button');
        menu.classList.toggle('active');
        const isExpanded = menu.classList.contains('active');
        button.setAttribute('aria-expanded', isExpanded);
    }
</script>

<?php include('./components/footer.php'); ?>

</body>
</html>
