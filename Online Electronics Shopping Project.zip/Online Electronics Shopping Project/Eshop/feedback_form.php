<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "eshop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $product = $_POST['product'];
    $rating = $_POST['rating'];
    $comments = $_POST['comments'];

    $sql = "INSERT INTO feedback (name, email, product, rating, comments) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssds", $name, $email, $product, $rating, $comments);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $conn->error;
    }
    
    $stmt->close();
}
$conn->close();
?>
    <?php include('./components/header.php'); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="css/feedback_form.css">
    <link rel="stylesheet" href="css/footer.css">

</head>
<body>
    <div class="form-body">
    <div class="feedback-container">
        <h2>Feedback Form</h2>
        <form id="feedbackForm" method="POST" action="">
            <div class="form-group">
                <label for="name">Your Name:</label>
                <input type="text" id="name" name="name" required placeholder="Enter your name">
            </div>
            
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required placeholder="Enter your email">
            </div>
            
            <div class="form-group">
                <label for="product">Product Purchased:</label>
                <select id="product" name="product" required>
                    <option value="">Select your product</option>
                    <option value="tv">Smart TV</option>
                    <option value="mobile">Mobile Phone</option>
                    <option value="smartphone">Smartphone</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Rate your experience:</label>
                <div class="rating">
                    <input type="hidden" id="rating" name="rating" value="0">
                    <span class="star" data-rating="1">★</span>
                    <span class="star" data-rating="2">★</span>
                    <span class="star" data-rating="3">★</span>
                    <span class="star" data-rating="4">★</span>
                    <span class="star" data-rating="5">★</span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="comments">Comments:</label>
                <textarea id="comments" name="comments" rows="5" placeholder="Tell us about your experience..."></textarea>
            </div>
            
            <button type="submit" class="submit-btn">Submit Feedback</button>
        </form>

        <div id="thankYouMessage" class="thank-you" style="display:none;">
            <div class="thank-you-content">
                <span class="check-mark">✓</span>
                <h3>Thank You!</h3>
                <p>Your feedback has been submitted successfully.</p>
            </div>
        </div>
    </div>

    <script>
document.getElementById("feedbackForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission to see the effect (remove this in production)
    
    // Hide the form
    document.getElementById("feedbackForm").style.display = "none";

    // Show the thank you message
    document.getElementById("thankYouMessage").style.display = "block";

    // Optionally, submit the form via AJAX (so the page doesn't reload)
    fetch("", {
        method: "POST",
        body: new FormData(this)
    }).then(response => response.text())
      .then(result => console.log(result))
      .catch(error => console.log('Error:', error));
});

        const stars = document.querySelectorAll('.star');
        let selectedRating = 0;

        function highlightStars(rating) {
            stars.forEach(star => {
                star.classList.toggle('active', star.dataset.rating <= rating);
            });
        }

        stars.forEach(star => {
            star.addEventListener('mouseover', () => highlightStars(star.dataset.rating));
            star.addEventListener('click', () => {
                selectedRating = star.dataset.rating;
                document.getElementById('rating').value = selectedRating;
                highlightStars(selectedRating);
            });
        });

        document.querySelector('.rating').addEventListener('mouseleave', () => {
            highlightStars(selectedRating);
        });
    </script>
    </div>
    <?php include('./components/footer.php'); ?>
    </body>
</html>