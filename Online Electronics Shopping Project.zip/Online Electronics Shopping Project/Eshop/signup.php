<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate input
    if (!empty($username) && !empty($email) && !empty($password)) {
        // Check if the email already exists in the database
        $check_email_query = "SELECT email FROM users WHERE email = ?";
        $stmt = $conn->prepare($check_email_query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Email already exists
            echo "<script>alert('Email already registered. Please use a different email.'); window.location.href='signup.php';</script>";
        } else {
            // Proceed with registration
            $stmt->close();

            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert the user data into the database
            $insert_query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->bind_param("sss", $username, $email, $hashed_password);

            if ($stmt->execute()) {
                // Redirect to login page after successful registration
                echo "<script>alert('Registration successful! Please log in.'); window.location.href='login.php';</script>";
            } else {
                // Show error if insertion fails
                echo "<script>alert('An error occurred while registering. Please try again.'); window.location.href='signup.php';</script>";
            }
        }

        $stmt->close();
    } else {
        // Validation failed
        echo "<script>alert('All fields are required.'); window.location.href='signup.php';</script>";
    }
}

// Close the database connection
$conn->close();
?>

<?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Electroshop</title>
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/signup_form.css">

</head>
<body>
    <div class="form-body">
    <div class="signup-container">
        <div class="signup-header">
            <h1>Register</h1>
            <p>Create an account to continue</p>
        </div>
        <form action="signup.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="signup-button">Register</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </div>
    </div>
    <script src="js/signup.js"></script>
    

    <?php include('./components/footer.php'); ?>

</body>
</html>
