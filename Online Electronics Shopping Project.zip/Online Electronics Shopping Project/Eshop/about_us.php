
<?php include('./components/header.php'); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ElectroShop</title>
    <link rel="stylesheet" href="css/Styles.css">
    <link rel="stylesheet" href="css/footer.css">

    

</head>
<body>
    <div class="about-container">
        <div class="about-header">
            <h1>About ElectroShop</h1>
            <p>Your Trusted Destination for Premium Electronics</p>
        </div>

        <div class="about-content">
            <img src="images/ElectroShopImage.JPG" alt="ElectroShop Store" class="about-image">
            <div class="about-text">
                <p>Welcome to ElectroShop, your premier destination for cutting-edge electronics. Since our establishment, we've been committed to providing our customers with the latest and most innovative technology solutions.</p>
                <p>We specialize in a carefully curated selection of high-quality electronics, including:</p>
                <ul style="margin: 20px 0 20px 20px;">
                    <li>Latest smartphones from leading brands</li>
                    <li>Smart TVs with cutting-edge display technology</li>
                    <li>High-performance laptops for work and gaming</li>
                </ul>
                <a href="contact_form.php" class="cta-button">Contact Us</a>
            </div>
        </div>

        <div class="about-features">
            <h2 style="text-align: center; color: #2B6CB0; margin-bottom: 30px;">Why Choose ElectroShop?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <h3>Expert Guidance</h3>
                    <p>Our team of tech experts is always ready to help you find the perfect device that matches your needs and budget.</p>
                </div>
                <div class="feature-card">
                    <h3>Quality Assurance</h3>
                    <p>We partner with authorized distributors to ensure you receive genuine products with full warranties.</p>
                </div>
                <div class="feature-card">
                    <h3>Competitive Pricing</h3>
                    <p>Enjoy the best deals on premium electronics with our price match guarantee and regular special offers.</p>
                </div>
                <div class="feature-card">
                    <h3>After-Sales Support</h3>
                    <p>Our commitment to you doesn't end with your purchase. We provide comprehensive after-sales support.</p>
                </div>
            </div>
        </div>
    </div>

    <?php include('./components/footer.php'); ?>

</body>
</html>