<?php
// Include the database connection file
include('database/db_connect.php'); // Ensure this path is correct and the file exists

// Start session to access user information
session_start();

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve product data from the form
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $product_price = isset($_POST['product_price']) ? floatval($_POST['product_price']) : 0.0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

    // Validate input data
    if ($user_id > 0 && $product_id > 0 && $quantity > 0) {
        // Calculate the total price
        $total_price = $product_price * $quantity;

        // Check if the product already exists in the cart for the user
        $query = "SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("ii", $user_id, $product_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                // Update the quantity and total price if the product already exists
                $row = $result->fetch_assoc();
                $new_quantity = $row['quantity'] + $quantity;
                $new_total_price = $product_price * $new_quantity;

                $update_query = "UPDATE cart SET quantity = ?, total_price = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);

                if ($update_stmt) {
                    $update_stmt->bind_param("idi", $new_quantity, $new_total_price, $row['id']);
                    if ($update_stmt->execute()) {
                        echo "Product quantity updated in cart!";
                    } else {
                        echo "Error updating cart: " . $update_stmt->error;
                    }
                    $update_stmt->close();
                } else {
                    echo "Failed to prepare the update statement: " . $conn->error;
                }
            } else {
                // Insert the product into the cart if it doesn't exist
                $insert_query = "INSERT INTO cart (user_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)";
                $insert_stmt = $conn->prepare($insert_query);

                if ($insert_stmt) {
                    $insert_stmt->bind_param("iiid", $user_id, $product_id, $quantity, $total_price);
                    if ($insert_stmt->execute()) {
                        echo "Product added to cart!";
                    } else {
                        echo "Error adding product to cart: " . $insert_stmt->error;
                    }
                    $insert_stmt->close();
                } else {
                    echo "Failed to prepare the insert statement: " . $conn->error;
                }
            }

            $stmt->close();
        } else {
            echo "Failed to prepare the select statement: " . $conn->error;
        }
    } else {
        echo "Invalid input data.";
    }
} else {
    echo "Invalid request.";
}

// Close the database connection
$conn->close();
?>
