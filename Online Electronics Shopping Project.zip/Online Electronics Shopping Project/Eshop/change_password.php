<?php
session_start();
include('database/db_connect.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents("php://input"), true);

    $user_id = $_SESSION['user_id'];
    $currentPassword = $data['currentPassword'];
    $newPassword = password_hash($data['newPassword'], PASSWORD_DEFAULT);

    // Check current password
    $query = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $query->bind_param("i", $user_id);
    $query->execute();
    $result = $query->get_result();
    $row = $result->fetch_assoc();

    if (!$row || !password_verify($currentPassword, $row['password'])) {
        echo json_encode(["error" => "Incorrect current password."]);
        exit;
    }

    // Update password
    $updateQuery = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $updateQuery->bind_param("si", $newPassword, $user_id);
    if ($updateQuery->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["error" => "Failed to update password."]);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="css/profile.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <div class="sidebar">
        <div class="user-info">
            <div class="avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="greeting">Hello, <span id="userNameDisplay">User</span></div>
        </div>
        <nav>
            <a href="profile.php" class="nav-item"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="change_password.php" class="nav-item active"><i class="fas fa-lock"></i> Change Password</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </div>

    <div class="main-content">
        <div class="page">
            <h2><i class="fas fa-lock"></i> Change Password</h2>
            <form id="changePasswordForm">
                <div class="form-group">
                    <label><i class="fas fa-key"></i> Current Password</label>
                    <input type="password" id="currentPassword" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> New Password</label>
                    <input type="password" id="newPassword" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Confirm New Password</label>
                    <input type="password" id="confirmNewPassword" required>
                </div>
                <button type="submit" class="save-btn"><i class="fas fa-save"></i> Update Password</button>
            </form>
            <p id="passwordMessage" style="color: red; display: none;"></p>
        </div>
    </div>
</div>

<script>
document.getElementById("changePasswordForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    let currentPassword = document.getElementById("currentPassword").value;
    let newPassword = document.getElementById("newPassword").value;
    let confirmNewPassword = document.getElementById("confirmNewPassword").value;
    let messageBox = document.getElementById("passwordMessage");

    if (newPassword !== confirmNewPassword) {
        messageBox.textContent = "New passwords do not match.";
        messageBox.style.display = "block";
        return;
    }

    let response = await fetch("change_password.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword })
    });

    let result = await response.json();

    if (result.success) {
        alert("Password updated successfully!");
        document.getElementById("changePasswordForm").reset();
    } else {
        messageBox.textContent = result.error || "Failed to update password.";
        messageBox.style.display = "block";
    }
});
</script>

</body>
</html>
