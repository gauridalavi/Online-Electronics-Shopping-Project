<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the product ID from the query string
$product_id = $_GET['id'] ?? null;

if (!$product_id || !is_numeric($product_id)) {
    die("Invalid product ID.");
}

// Fetch product details including initial stock quantity
$sql = "SELECT p.*, c.name AS category_name, b.name AS brand_name, p.stock_quantity 
        FROM products p
        JOIN categories c ON p.category_id = c.id
        JOIN brands b ON p.brand_id = b.id
        WHERE p.id = $product_id";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    die("Product not found.");
}

$product = $result->fetch_assoc();

// Calculate remaining stock by subtracting ordered quantity from order_items table
$order_sql = "SELECT SUM(oi.quantity) AS total_ordered 
              FROM order_items oi 
              JOIN orders o ON oi.order_id = o.id 
              WHERE oi.product_id = $product_id";
$order_result = $conn->query($order_sql);
$total_ordered = ($order_result->num_rows > 0) ? $order_result->fetch_assoc()['total_ordered'] : 0;
$available_stock = $product['stock_quantity'] - ($total_ordered ?? 0);

// Fetch product reviews from the database
$reviews_sql = "SELECT * FROM reviews WHERE product_id = $product_id ORDER BY created_at DESC";
$reviews_result = $conn->query($reviews_sql);
$reviews = [];
if ($reviews_result->num_rows > 0) {
    while ($review = $reviews_result->fetch_assoc()) {
        $reviews[] = $review;
    }
}
?>

<?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Product Page</title>
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/products_details.css">
</head>
<body>
    <div class="form-body">
        <div class="product-container">
            <div class="product-images">
                <div class="main-image">
                    <img src="Admin/<?php echo htmlspecialchars($product['image_main']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" id="mainImage">
                </div>
                <div class="thumbnail-container">
                    <?php if (!empty($product['image_thumb1'])) { ?>
                        <img src="Admin/<?php echo htmlspecialchars($product['image_thumb1']); ?>" alt="Thumbnail 1" class="thumbnail active" onclick="changeImage(this)">
                    <?php } ?>
                    <?php if (!empty($product['image_thumb2'])) { ?>
                        <img src="Admin/<?php echo htmlspecialchars($product['image_thumb2']); ?>" alt="Thumbnail 2" class="thumbnail" onclick="changeImage(this)">
                    <?php } ?>
                </div>
            </div>
            <div class="product-info">
                <span class="brand-badge">Brand: <?php echo htmlspecialchars($product['brand_name']); ?></span>
                <h1><?php echo htmlspecialchars($product['name']); ?></h1>
                <div class="rating">★★★★☆ <span>(4.5)</span></div>
                <div class="price">
                    <span class="current-price">₹<?php echo number_format($product['price'], 2); ?></span>
                    <?php if (!empty($product['original_price'])) { ?>
                        <span class="original-price">₹<?php echo number_format($product['original_price'], 2); ?></span>
                    <?php } ?>
                </div>
                <div class="stock-info">
                    <?php if ($available_stock > 0) { ?>
                        <span class="in-stock">In Stock (<?php echo $available_stock; ?> available)</span>
                    <?php } else { ?>
                        <span class="out-of-stock">Out of Stock</span>
                    <?php } ?>
                </div>
                <div class="button-container" style="display: flex; gap: 10px; align-items: center;">
                    <form action="my_cart.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                        <input type="hidden" name="product_price" value="<?php echo htmlspecialchars($product['price']); ?>">
                        <input type="number" name="quantity" value="1" min="1" max="<?php echo $available_stock; ?>" class="quantity-input" style="width: 50px;" <?php echo ($available_stock > 0) ? '' : 'disabled'; ?>>
                        <button type="submit" class="add-to-cart" style="background-color: #007bff; color: white; border: none; padding: 10px 15px; cursor: pointer;" <?php echo ($available_stock > 0) ? '' : 'disabled'; ?>>Add to Cart</button>
                    </form>

                    <form action="wishlist.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
                        <button type="submit" class="wishlist" style="background-color: #f0c14b; border: none; padding: 10px 15px; cursor: pointer;"><i>❤️</i> Wishlist</button>
                    </form>

                    <button class="review-btn" onclick="toggleReviewForm()" style="background-color: #ff9900; border: none; padding: 10px 15px; cursor: pointer;">Review</button>
                </div>
            </div>
        </div>

        <!-- Review Form (Hidden initially) -->
        <div id="reviewForm" class="review-form" style="display: none;">
            <h3>Submit Review</h3>
            <form action="submit_review.php" method="POST">
                <input type="hidden" name="product_id" value="<?php echo isset($_GET['id']) ? (int) $_GET['id'] : 0; ?>">

                <label for="name">Your Name:</label>
                <input type="text" name="name" id="name" placeholder="Enter your name" required>
                <br>

                <!-- Star Ratings -->
                <label for="rating">Rating:</label>
                <div class="star-rating">
                    <input type="radio" name="rating" value="5" id="star5" required><label for="star5">★</label>
                    <input type="radio" name="rating" value="4" id="star4"><label for="star4">★</label>
                    <input type="radio" name="rating" value="3" id="star3"><label for="star3">★</label>
                    <input type="radio" name="rating" value="2" id="star2"><label for="star2">★</label>
                    <input type="radio" name="rating" value="1" id="star1"><label for="star1">★</label>
                </div>
                <br>

                <label for="comments">Comments:</label>
                <textarea name="comments" id="comments" rows="3" placeholder="Write your review" required></textarea>
                <br>

                <button type="submit" class="submit-review">Submit Review</button>
            </form>
        </div>

        <div class="product-details">
            <h2>Product Description</h2>
            <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
        </div>

        <!-- Display Customer Reviews -->
        <div class="reviews-section">
            <h3>Customer Reviews</h3>
            <?php if (count($reviews) > 0): ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review">
                        <div class="review-header">
                            <span class="review-author"><?php echo htmlspecialchars($review['name']); ?></span>
                            <span class="review-rating">
                                <?php for ($i = 0; $i < $review['rating']; $i++): ?>
                                    ★
                                <?php endfor; ?>
                                <span class="review-date"><?php echo date('F j, Y', strtotime($review['created_at'])); ?></span>
                            </span>
                        </div>
                        <div class="review-comments">
                            <p><?php echo nl2br(htmlspecialchars($review['comments'])); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No reviews yet. Be the first to review this product!</p>
            <?php endif; ?>
        </div>

    </div>

    <script>
        function changeImage(element) {
            const mainImage = document.getElementById('mainImage');
            mainImage.src = element.src;
            document.querySelectorAll('.thumbnail').forEach(img => img.classList.remove('active'));
            element.classList.add('active');
        }

        function toggleReviewForm() {
            const reviewForm = document.getElementById('reviewForm');
            reviewForm.style.display = reviewForm.style.display === 'none' ? 'block' : 'none';
        }
    </script>

    <?php include('./components/footer.php'); ?>
</body>
</html>