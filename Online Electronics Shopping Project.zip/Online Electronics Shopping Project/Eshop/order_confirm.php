<?php
session_start();
require 'vendor/autoload.php';
use Razorpay\Api\Api;

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Razorpay API Credentials
$keyId = "rzp_test_dgqSY6c4G84QHu";
$keySecret = "bGta1T9XH4mpioSptQCBQ3XH";
$api = new Api($keyId, $keySecret);

// Get Payment Details
$payment_id = $_GET['payment_id'] ?? null;
$payment_method = $_GET['method'] ?? 'razorpay';
$payment_status = "pending"; // Default status

if ($payment_method === "razorpay" && !empty($payment_id)) {
    try {
        $payment = $api->payment->fetch($payment_id); // Fetch payment details

        // Debug: Print Razorpay API response
        echo "<pre>";
        print_r($payment);
        echo "</pre>";

        // Check payment status from Razorpay API
        if ($payment->status === "captured") {
            $payment_status = "completed"; // Razorpay payment is successful
        } elseif ($payment->status === "authorized") {
            $payment_status = "authorized"; // Payment is authorized but not captured
        } else {
            $payment_status = "failed"; // Payment failed
        }
    } catch (Exception $e) {
        die("Error verifying payment: " . $e->getMessage());
    }
} elseif ($payment_method === "cod") {
    $payment_id = "COD-" . uniqid(); // Generate unique payment ID for COD
    $payment_status = "pending"; // COD orders remain pending
}

// Debug: Show updated payment status before inserting into database
echo "Debug: Final Payment Status - " . $payment_status . "<br>";

// Ensure Payment ID is not empty before processing order
if (empty($payment_id)) {
    die("Error: Payment ID is missing.");
}

// Retrieve Order Details from Session
$customer = $_SESSION['customer_details'];
$cart_items = $_SESSION['cart_items'];
$total_price = $_SESSION['total_price'];
$user_id = $_SESSION['user_id'];

// Combine shipping address
$shipping_address = "{$customer['address']}, {$customer['city']}, {$customer['state']}, {$customer['zip']}";

// Insert Order into `orders` table
$order_query = "INSERT INTO orders (user_id, total_price, payment_method, payment_id, full_name, email, phone_no, shipping_address) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("idssssss", $user_id, $total_price, $payment_method, $payment_id, $customer['name'], $customer['email'], $customer['phone'], $shipping_address);

if ($stmt->execute()) {
    $order_id = $stmt->insert_id; // Get Order ID

    // Insert Payment Data into `payment` Table
    $payment_query = "INSERT INTO payment (order_id, payment_method, payment_id, amount, status, created_at) 
                      VALUES (?, ?, ?, ?, ?, NOW())";
    $payment_stmt = $conn->prepare($payment_query);
    $payment_stmt->bind_param("issds", $order_id, $payment_method, $payment_id, $total_price, $payment_status);
    
    if ($payment_stmt->execute()) {
        echo "Debug: Payment recorded successfully!<br>";
    } else {
        echo "Debug: Payment insert failed - " . $payment_stmt->error . "<br>";
    }

    // Insert order items & update stock
    foreach ($cart_items as $item) {
        $item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        $item_stmt = $conn->prepare($item_query);
        $item_stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['total_price']);
        $item_stmt->execute();
    }

    // Clear cart
    $clear_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $clear_cart->bind_param("i", $user_id);
    $clear_cart->execute();

    // Redirect to order history
    header("Location: order_history.php?order_id=" . $order_id);
    exit();
} else {
    die("Error: " . $stmt->error);
}

// Close Connections
$stmt->close();
$conn->close();
?>
