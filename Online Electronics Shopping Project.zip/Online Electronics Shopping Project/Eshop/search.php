<?php
// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eshop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the search query from the URL (GET method)
$query = isset($_GET['query']) ? $_GET['query'] : '';

// Initialize an empty array for search results
$products = [];

if (!empty($query)) {
    // SQL query to search for products matching the query
    $sql = "SELECT * FROM products WHERE name LIKE ? OR description LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $query . "%";  // Add percent signs for a partial match
    $stmt->bind_param("ss", $searchTerm, $searchTerm);  // Bind the search term to the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the results into an array
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $stmt->close();
}
?>
    <?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link rel="stylesheet" href="css/Styles.css">
    <link rel="stylesheet" href="css/footer.css">

</head>
<body>
    <header>
        <!-- Include your existing header here -->
    </header>

    <div class="search-results">
        <h1>Search Results for "<?php echo htmlspecialchars($query); ?>"</h1>
        <?php if (count($products) > 0): ?>
    <div class="search-results-container">
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <img src="Admin/uploads/productImages/<?php echo $product['id']; ?>/<?php echo basename($product['image_main']); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>">
                <div class="product-details">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="price">₹<?php echo $product['price']; ?></p>
                    <a href="products_details.php?id=<?php echo $product['id']; ?>" class="view-details">View Details</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <p>No products found for your search.</p>
<?php endif; ?>



<?php include('./components/footer.php'); ?>
   
</body>
</html>
