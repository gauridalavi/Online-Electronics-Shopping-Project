<?php
session_start();
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    header("Location: login.php?return=order_history.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$order_id = $_GET['order_id'] ?? null;
if (!$order_id) {
    die("Invalid order.");
}

// Fetch order details
$sql = "SELECT * FROM orders WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    die("Order not found.");
}

// Fetch order items with product details
$sql_items = "SELECT oi.*, p.name, p.image_main FROM order_items oi 
              JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
$stmt = $conn->prepare($sql_items);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 700px;
            margin: auto;
        }
        h2 {
            color: #333;
        }
        .order-info {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #e9ecef;
            border-radius: 5px;
        }
        .product-list {
            list-style: none;
            padding: 0;
        }
        .product-item {
            display: flex;
            align-items: center;
            background: #fff;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }
        .product-image {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 5px;
            margin-right: 15px;
        }
        .product-details {
            text-align: left;
        }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Order Details (ID: <?php echo htmlspecialchars($order['id']); ?>)</h2>
    <div class="order-info">
        <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
        <p><strong>Total Price:</strong> ₹<?php echo number_format($order['total_price'], 2); ?></p>
        <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></p>
        <p><strong>Shipping Address:</strong> <?php echo htmlspecialchars($order['shipping_address']); ?></p>
    </div>

    <h3>Ordered Items:</h3>
    <ul class="product-list">
        <?php if (empty($order_items)) { ?>
            <p>No items found for this order.</p>
        <?php } else { ?>
            <?php foreach ($order_items as $item) { ?>
                <li class="product-item">
                    <img src="Admin/<?php echo htmlspecialchars($item['image_main']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="product-image">
                    <div class="product-details">
                        <p><strong><?php echo htmlspecialchars($item['name']); ?></strong></p>
                        <p>Qty: <?php echo htmlspecialchars($item['quantity']); ?></p>
                        <p>₹<?php echo number_format($item['price'], 2); ?></p>
                    </div>
                </li>
            <?php } ?>
        <?php } ?>
    </ul>

    <a href="order_history.php" class="back-btn">Back to Orders</a>
</div>

</body>
</html>
