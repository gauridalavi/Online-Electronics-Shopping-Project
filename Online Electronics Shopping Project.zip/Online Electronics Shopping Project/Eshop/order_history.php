<?php
session_start();
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    header("Location: login.php?return=order_history.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link rel="stylesheet" href="css/footer.css">

    <style>
        .form-body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            padding: 20px;
            display: flex;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 700px;
            margin: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #3399cc;
            color: white;
        }
        .btn {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .details-btn {
            background-color: #28a745;
            color: white;
        }
        .cancel-btn {
            background-color: #dc3545;
            color: white;
        }
        .cancel-btn:disabled {
            background-color: #aaa;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <div class="form-body">
    <div class="container">
        <h2>Your Order History</h2>
        <table>
            <tr>
                <th>Order ID</th>
                <th>Total Amount</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($orders as $order) { ?>
            <tr>
                <td><?php echo $order['id']; ?></td>
                <td>₹<?php echo number_format($order['total_price'], 2); ?></td>
                <td><?php echo ucfirst($order['payment_method']); ?></td>
                <td><?php echo $order['status']; ?></td>
                <td><?php echo date("d M Y, h:i A", strtotime($order['order_date'])); ?></td>
                <td>
                    <a href="order_details.php?order_id=<?php echo $order['id']; ?>" class="btn details-btn">View</a>
                    <form method="POST" action="cancel_order.php" style="display:inline;">
                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                        <button type="submit" class="btn cancel-btn" <?php echo ($order['status'] != 'Pending') ? 'disabled' : ''; ?>>
                            Cancel
                        </button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
    </div>
    <?php include('./components/footer.php'); ?>

</body>
</html>
