<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get Razorpay payment ID from Razorpay response
if (isset($_POST['payment_id']) && isset($_POST['order_id'])) {
    $payment_id = $_POST['payment_id'];
    $order_id = $_POST['order_id'];

    // Update the payment status to 'completed' in the database
    $update_query = "UPDATE payment SET status='completed' WHERE payment_id='$payment_id' AND order_id='$order_id'";
    if ($conn->query($update_query) === TRUE) {
        echo "Payment status updated successfully!";
    } else {
        echo "Error updating payment status: " . $conn->error;
    }
} else {
    echo "Invalid request!";
}

$conn->close();
?>
