<?php
session_start(); // Start the session

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'eshop');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Prepare the SQL statement
    $query = "SELECT id, username, password FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("s", $email); // Use email from the form
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the user data
            $user = $result->fetch_assoc();

            // Verify the password
            if (password_verify($password, $user['password'])) {
                // Save user details to the session
                $_SESSION['isLoggedIn'] = true;
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_id'] = $user['id']; // Ensure 'id' column exists in 'users' table

                // Debug session data
                echo '<pre>';
                print_r($_SESSION);
                echo '</pre>';

                // Redirect to index.php
                header("Location: index.php");
                exit();
            } else {
                // Incorrect password
                $error_message = "Invalid email or password.";
            }
        } else {
            // No user found
            $error_message = "Invalid email or password.";
        }
        $stmt->close();
    } else {
        // SQL statement error
        $error_message = "Error: " . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="css/login_form.css">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <div class="form-body">
    <div class="login-container">
        <div class="login-header">
            <h1>Login</h1>
            <p>Login to access your account</p>
        </div>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="forgot-password">
    <a href="forgot_password.php">Forgot Password?</a>
</div>

            <button type="submit" class="login-button">Login</button>
        </form>
        <div class="signup-link">
            New to Electroshop? <a href="signup.php">Create an account</a>
        </div>
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
    </div>
    </div>
    <?php include('./components/footer.php'); ?>
</body>
</html>
