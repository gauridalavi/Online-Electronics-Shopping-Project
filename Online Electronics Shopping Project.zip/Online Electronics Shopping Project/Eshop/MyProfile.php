<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Account</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="css/profile.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="user-info">
                <div class="avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="greeting">Hello, <span id="userNameDisplay">Guest</span></div>
            </div>
            <nav>
                <a href="#" class="nav-item" data-page="orders">
                    <i class="fas fa-shopping-bag"></i> MY ORDERS
                </a>
                <a href="#" class="nav-item" data-page="settings">
                    <i class="fas fa-cog"></i> ACCOUNT SETTINGS
                </a>
                <div class="sub-menu">
                    <a href="profile.php" class="nav-item active" data-page="personal-info">
                        <i class="fas fa-user-circle"></i> Personal Information
                    </a>
                    <a href="change_password.php" class="nav-item" data-page="change-password">
                        <i class="fas fa-lock"></i> Change Password
                    </a>
                </div>
            </nav>
        </div>
        
        <div class="main-content">
            <div id="ordersPage" class="page" style="display: none;">
                <h2><i class="fas fa-shopping-bag"></i> My Orders</h2>
                <p>No orders found.</p>
            </div>

            <div id="personal-infoPage" class="page">
                <div class="header">
                    <h2><i class="fas fa-user-circle"></i> Personal Information</h2>
                    <button id="editBtn" class="edit-btn">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                </div>
                
                <form id="personalInfoForm">
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> First Name</label>
                        <input type="text" id="firstName" disabled>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email</label>
                        <input type="email" id="email" disabled>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Mobile Number</label>
                        <input type="tel" id="mobile" pattern="[0-9]{10}" disabled>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-home"></i> Address</label>
                        <input type="text" id="address" disabled>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-city"></i> City</label>
                            <input type="text" id="city" disabled>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-map"></i> State</label>
                            <input type="text" id="state" disabled>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-map-pin"></i> Zip Code</label>
                            <input type="text" id="zipCode" disabled>
                        </div>
                    </div>

                    <div class="button-group">
                        <button type="submit" id="saveBtn" class="save-btn" style="display: none;">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                        <button type="button" id="deleteAccountBtn" class="delete-btn">
                            <i class="fas fa-trash"></i> Delete Account
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
                </form>
            </div>

     
                
           
    <script>
        document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (newPassword !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            fetch('change_password.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ currentPassword, newPassword })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Password updated successfully!');
                    document.getElementById('changePasswordForm').reset();
                } else {
                    alert(data.error);
                }
            });
        });
    </script>

</body>
</html>
