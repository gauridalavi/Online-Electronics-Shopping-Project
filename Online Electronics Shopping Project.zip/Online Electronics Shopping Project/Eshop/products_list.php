<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products List</title>
    <style>
        /* General styling */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }

        .product-grid {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

     .product-card {
        position: relative;
        background-color: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        display: flex;
        flex-direction: column;
        transition: box-shadow 0.10s ease;
        width: 250px; /* Set a fixed width */
        margin: 10px; /* Add spacing between cards */
        box-sizing: border-box; /* Include padding and border in the width */
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .product-card img {
             width: 90%;
            height: 100px;
            object-fit: contain;
            margin-bottom: 25px;
        }

        .product-details {
            padding: 15px;
            text-align: center;
        }

        .product-details h3 {
             font-size: 16px;
            font-weight: bold;
            margin-bottom: 5px;
            height: 50px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            line-clamp: 2;
            -webkit-box-orient: vertical;
            cursor: pointer;
        }

        .product-details .price {
            font-size: 16px;
            font-weight: bold;
            color: #007bff;
            margin: 10px 0;
        }

        .product-details .view-details {
            display: inline-block;
            padding: 10px 15px;
            font-size: 14px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            background-color:rgb(204, 192, 32);
            color: #fff;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .product-details .view-details:hover {
            background-color:rgb(218, 238, 120);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Our Products</h1>
        <div class="product-grid">
            <?php
            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'eshop');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch all products
            $products = $conn->query("SELECT * FROM products");

            while ($product = $products->fetch_assoc()) { ?>
                <div class="product-card">
                    <img src="Admin/uploads/productImages/<?php echo $product['id']; ?>/<?php echo basename($product['image_main']); ?>" 
                         alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <div class="product-details">
                        <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="price">₹<?php echo $product['price']; ?></p>
                        <a href="products_details.php?id=<?php echo $product['id']; ?>" class="view-details">View Details</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>
