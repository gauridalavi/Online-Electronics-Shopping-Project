<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    header("Location: login.php?return=place_order.php");
    exit();
}

if (!isset($_SESSION['checkout_data'])) {
    header("Location: checkout.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$checkoutData = $_SESSION['checkout_data'];
$paymentMethod = $_POST['paymentMethod'];
$shipping_address = "{$checkoutData['address']}, {$checkoutData['city']}, {$checkoutData['state']}, {$checkoutData['zip']}";

// Fetch cart items
$cartQuery = "SELECT product_id, quantity, total_price FROM cart WHERE user_id = ?";
$cartStmt = $conn->prepare($cartQuery);
$cartStmt->bind_param("i", $user_id);
$cartStmt->execute();
$cartResult = $cartStmt->get_result();

if ($cartResult->num_rows === 0) {
    echo "<script>alert('Your cart is empty.'); window.location.href='my_cart.php';</script>";
    exit();
}

// Insert order into database
$insertOrder = "INSERT INTO orders (user_id, product_id, shipping_address, payment_method, total_price, quantity, status, order_date) VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())";
$orderStmt = $conn->prepare($insertOrder);

while ($cartItem = $cartResult->fetch_assoc()) {
    $orderStmt->bind_param("iissdi", $user_id, $cartItem['product_id'], $shipping_address, $paymentMethod, $cartItem['total_price'], $cartItem['quantity']);
    $orderStmt->execute();
}

// Clear cart
$conn->query("DELETE FROM cart WHERE user_id = $user_id");

echo "<script>alert('Order placed successfully!'); window.location.href='order_history.php';</script>";
$conn->close();
?>
