-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2025 at 01:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$LayzHqpvUdyV2d8.R1XJAuQgZ/CQmOvkNdGd8DQBQfJPu9TG.NwDy');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `category_id`) VALUES
(1, 'Oppo', 1),
(2, 'Samsung', 1),
(3, 'Vivo', 1),
(4, 'Sony', 2),
(5, 'LG', 2),
(6, 'Dell', 3),
(7, 'HP', 3),
(8, 'Asus', 3);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `total_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Smartphones'),
(2, 'TVs'),
(3, 'Laptops');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` enum('Pending','Processing','Shipped','Delivered','cancelled') DEFAULT 'Pending',
  `total_price` decimal(10,2) NOT NULL,
  `shipping_address` text NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `phone_no` varchar(15) NOT NULL,
  `payment_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `full_name`, `email`, `status`, `total_price`, `shipping_address`, `payment_method`, `order_date`, `updated_date`, `phone_no`, `payment_id`) VALUES
(1, 1, 'Gauri Chandrakant Dalavi', 'gauridalavi1@gmail.com', 'Pending', 76999.00, 'At post-masur, karad, maharashtra, 415106', 'razorpay', '2025-02-18 11:39:59', '2025-02-18 11:39:59', '9579926080', 'pay_Px9yp1MQY84JCP'),
(2, 2, 'Sargam Sayaji Yadav', 'sargam116@gmail.com', 'Pending', 71490.00, 'yadavwadi, karad, maharashtra, 415106', 'razorpay', '2025-02-18 11:51:08', '2025-02-18 11:51:08', '7894561232', 'pay_PxAAavyVjECYef'),
(3, 3, 'Sakshi Ajit Chavan', 'sakshichavan11@gmail.com', 'Pending', 13490.00, 'At post-masur, karad, maharashtra, 415106', 'cod', '2025-02-18 11:56:06', '2025-02-18 11:56:06', '9878988450', 'COD-67b4755683258');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 1, 1, 76999.00),
(2, 2, 4, 1, 71490.00),
(3, 3, 7, 1, 13490.00);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_id` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `order_id`, `payment_method`, `payment_id`, `amount`, `status`, `created_at`) VALUES
(1, 1, 'razorpay', 'pay_Px9yp1MQY84JCP', 76999.00, 'completed', '2025-02-18 11:39:59'),
(2, 2, 'razorpay', 'pay_PxAAavyVjECYef', 71490.00, 'completed', '2025-02-18 11:51:08'),
(3, 3, 'cod', 'COD-67b4755683258', 13490.00, 'pending', '2025-02-18 11:56:06');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) DEFAULT NULL,
  `discount` int(11) DEFAULT 0,
  `image_main` varchar(255) DEFAULT NULL,
  `image_thumb1` varchar(255) DEFAULT NULL,
  `image_thumb2` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `trending` tinyint(1) DEFAULT 0,
  `best_selling` tinyint(1) DEFAULT 0,
  `stock_quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `brand_id`, `name`, `description`, `price`, `original_price`, `discount`, `image_main`, `image_thumb1`, `image_thumb2`, `created_at`, `is_active`, `trending`, `best_selling`, `stock_quantity`) VALUES
(1, 1, 2, 'Samsung Galaxy S23 Ultra 5G AI Smartphone (Cream, 12GB, 256GB Storage)', 'Experience the power of Galaxy AI with S23 Ultra to effortlessly perfect your photos with Photo Assist, communicate quickly outside your language with Live Translate or pick the right tone with Chat Assist, Galaxy AI makes your emories brighter, your communication easier and your tone nicer and let you sail through the life effortlessly, just like that!.                                                                                         ---Features---\r\n12 GB RAM | 256 GB ROM\r\n200MP + 10MP + 12MP + 10MP | 12MP Front Camera', 76999.00, 148999.00, 49, 'uploads/productImages/1/samsung1.jpg', 'uploads/productImages/1/samsung1.1.jpg', 'uploads/productImages/1/samsung1.2.jpg', '2025-02-04 18:31:44', 1, 1, 0, 20),
(2, 3, 8, 'ASUS VivoBook 15 Intel Core i7 10th Gen 16GB 512GB SSD Windows 11', 'Easy portability. Effortless productivity. Whether for work or play, ASUS VivoBook 14 is the entry-level laptop that delivers powerful performance and immersive visuals. Its NanoEdge display boasts a matte anti-glare coating for a truly engaging experience. Inside, it’s powered by up to an 11th Intel Core processor with DDR4 3200MHz RAM, and NVIDIA GeForce graphics (optional).', 42990.00, 65999.00, 35, 'uploads/productImages/2/Asus1.jpg', 'uploads/productImages/2/Asus1.1.jpg', 'uploads/productImages/2/Asus1.3.jpg', '2025-02-04 18:35:50', 1, 1, 0, 15),
(3, 2, 4, 'Sony BRAVIA 2 Series 108 cm (43 inches) 4K Ultra HD Smart LED Google TV K-43S20B (Black)', 'Enhanced clearness and smoothness when watching fast-moving action. Motionflow XR increases the number of images seen every second for smoother motion while controlling LED backlighting and reducing image blur for clearer pictures.Clear and expansive audio quality.\r\nOur unique Clear Phase adjusts the time alignment of sounds at certain heights and evens out their volume for acoustic harmony.\r\n', 39990.00, 59900.00, 33, 'uploads/productImages/3/sony1.jpg', 'uploads/productImages/3/sony1.1.jpg', 'uploads/productImages/3/sony1.2.jpg', '2025-02-04 18:39:35', 1, 1, 0, 15),
(4, 3, 7, 'HP Pavilion 15 Laptop (13th Gen Intel Core i5 / 16 GB RAM/ 512 GB SSD/ 15.6 inch (39.6 cm) Display/ Intel Iris Xe Graphics/ Win 11/ Office) EG3081TU', 'Do your thing, all day and wherever you prefer, \r\n                    thanks to the HP 15\" Laptop PC with a lightweight design and long battery life. Enjoy comfortable computing with a flicker-free screen[2] and experience reliable performance thanks to the Intel® Core™ Processor[3]. Plus, made with the planet in mind, is EPEAT® Silver registered[4] and ENERGY STAR® certified.', 71490.00, 84834.00, 16, 'uploads/productImages/4/HP3.jpg', 'uploads/productImages/4/HP3.1.jpg', 'uploads/productImages/4/HP3.2.jpg', '2025-02-04 18:42:40', 1, 1, 0, 15),
(5, 1, 3, 'vivo T3 Lite 5G (Vibrant Green, 128 GB)  (6 GB RAM)', 'The Vivo T3 Lite 5G 6.56-inch Smartphone offers an expansive 6.56-inch LCD screen and an impressive 1612x720 resolution. This enables you to catch up on your favourite shows even when you’re on the go. Plus, the 90Hz refresh rate makes interactions with your smartphone feel instantaneous and incredibly responsivell vary depending on the operator and may change after software upgrades are performed..', 11499.00, 15499.00, 22, 'uploads/productImages/5/vivo1.jpg', 'uploads/productImages/5/vivo1.2.jpg', 'uploads/productImages/5/vivo1.3.jpg', '2025-02-04 18:50:18', 1, 0, 1, 20),
(6, 1, 1, 'OPPO A3X 4G (Ocean Blue, 4GB RAM, 128GB Storage)', 'Stay ahead of the trend with the OPPO A3X 4G 128 GB (Ocean Blue, 4 GB RAM) that comes with a sleek design and attractive looks.The phone being 186 grams and measuring 165.77 mmx76.08 mmx7.68 mm(height x width x ickness) offers you a slip-free grip. Besides, the mobile is available at a starting price of Rs. 9999 in Ocean Blue color.', 9859.00, 13999.00, 28, 'uploads/productImages/6/oppo2.jpg', 'uploads/productImages/6/oppo2.1.jpg', 'uploads/productImages/6/oppo2.2.jpg', '2025-02-04 18:53:38', 1, 0, 1, 20),
(7, 2, 5, 'LG 80 cm (32 inches) HD Ready Smart LED TV 32LQ643BPTA (Black)', 'Enhanced clearness and smoothness when watching fast-moving action. Motionflow XR increases the number of images seen every second for smoother motion while controlling LED backlighting and reducing image blur for clearer pictures. Clear and expansive audio quality. Our unique Clear Phase adjusts the time alignment of sounds at certain heights and evens out their volume for acoustic harmony.', 13490.00, 21490.00, 39, 'uploads/productImages/7/LG1.jpg', 'uploads/productImages/7/LG1.1.jpg', 'uploads/productImages/7/LG1.2.jpg', '2025-02-04 18:55:56', 1, 0, 1, 10),
(8, 3, 6, 'Dell Inspiron 15 Laptop, Intel Core i5-1135G7 Processor, 8Gb, 512Gb SSd, Win 11, Integrated Graphics, 15.6\" (39.62 cm) FHD Display, 15 Month McAfee, Backlit Keyboard,  platinum Silver ', 'Specifications Of Dell Inspiron 15 Laptop (12th Gen Core i5/ 16GB RAM/ 512GB SSD/ 15.6 inch (39.6 cm)/ Intel Iris Xe Graphics/ Win 11/ MS Office)   OIN352010051RINS1Misplay // Graphics:NVIDIA GeForce RT', 48900.00, 75000.00, 35, 'uploads/productImages/8/DEll3.jpg', 'uploads/productImages/8/Dell3.1.jpg', 'uploads/productImages/8/Dell3.2.jpg', '2025-02-04 19:01:16', 1, 0, 1, 15),
(9, 1, 1, 'OPPO A18 (Glowing Blue, 128 GB)  (4 GB RAM)', 'Stay ahead of the trend with the OPPO A3X 4G 128 GB (Ocean Blue, 4 GB RAM) that comes with a sleek design and attractive looks.The phone being 186 grams and measuring 165.77 mmx76.08 mmx7.68 mm(height x width x ckness) offers you a slip-free grip. Besides, the mobile is available at a starting price of Rs. 9999 in Ocean Blue color', 9499.00, 15999.00, 40, 'uploads/productImages/9/oppo3.jpg', 'uploads/productImages/9/oppo3.1.jpg', 'uploads/productImages/9/oppo3.2.jpg', '2025-02-06 18:46:00', 1, 0, 0, 10),
(10, 1, 2, 'Samsung Galaxy M13 5G (6 GB RAM, 128 GB ROM, Aqua Green)', 'Network : The bandwidths supported by the device may vary depending on the region or service provider. Battery: Actual battery life varies by network environment, features and apps used, frequency of calls and messages, number of times charged, and many other factors. User Available Memory: Actual user memory will vary depending on the operator and may change after software upgrades are performed.', 14999.00, 16999.00, 16, 'uploads/productImages/10/samsung3.jpg', 'uploads/productImages/10/samsung3.1.jpg', 'uploads/productImages/10/samsung3.2.jpg', '2025-02-08 04:05:49', 1, 0, 0, 10),
(11, 1, 3, 'Vivo T3x 5G (Crimson Bliss, 128 GB) (6 GB RAM)', 'Bring home the ultimate gaming experience, enhanced mobile performance, and more with the Vivo T1x smartphone.\r\n                     This mobile phone features a 16.71 cm (6.58) FHD in-cell display to ensure vibrant and sharp visuals.\r\n                      Also, this mobile phone comes with a 50 MP Main Camera so that you can click crystal clear pictures every day.  Furthermore, leveraging the 5000 mAh battery, you can fulfill all your entertainment or working needs without worrying about the battery running out of juice.\r\n', 14909.00, 18990.00, 25, 'uploads/productImages/11/vivo2.jpg', 'uploads/productImages/11/vivo2.1.jpg', 'uploads/productImages/11/vivo2.2.jpg', '2025-02-08 04:08:56', 1, 0, 0, 15),
(12, 1, 3, 'Vivo Y200e 5G Smartphone (8GB RAM, 128GB Storage) 6.67-inch FHD+ AMOLED display, Snapdragon® 4s Gen 2 Processor (Saffron Delight)', 'The Vivo Y200e is a smartphone that seamlessly blends style with substance, \r\n                    featuring an innovative EcoFiber Leather finish that not only feels luxurious but also stands as a testament to Vivo’s commitment to environmentally friendly design', 19999.00, 25999.00, 25, 'uploads/productImages/12/vivo3.jpg', 'uploads/productImages/12/vivo3.1.jpg', 'uploads/productImages/12/vivo3.2.jpg', '2025-02-08 04:11:07', 1, 0, 0, 10),
(13, 2, 4, 'Sony BRAVIA 2 Series 108 cm (43 inches) 4K Ultra HD Smart LED Google TV K-43S25 (Black)', 'Watch old favourites in close to 4K quality. Our 4K X-Reality PRO analyses, cleans and refines images using our unique 4K database so you can indulge in stunning pictures from virtually any content.\r\n                    See natural shades and hues. Live Colour expands the colours of images to the reproducible colours of the TV so everything you see looks vivid and real.', 44700.00, 69900.00, 36, 'uploads/productImages/13/sony2.jpg', 'uploads/productImages/13/sony2.1.jpg', 'uploads/productImages/13/sony2.3.jpg', '2025-02-08 04:12:56', 1, 0, 0, 10),
(14, 2, 4, 'Sony BRAVIA 80 cm (32 inches) HD Ready Smart LED Google TV KD-32W825 (Black)', 'Watch old favourites in close to 4K quality. Our 4K X-Reality PRO analyses, cleans and refines images using our unique 4K database so you can indulge in stunning pictures from virtually any content.\r\n                    See natural shades and hues.', 23990.00, 34900.00, 31, 'uploads/productImages/14/sony3.jpg', 'uploads/productImages/14/sony3.1.jpg', 'uploads/productImages/14/sony3.2.jpg', '2025-02-08 04:14:23', 1, 0, 0, 10),
(15, 2, 5, 'LG 139 cm (55 inches) 4K Ultra HD Smart LED TV 55UR7500PSC (Dark Iron Gray)', 'Connectivity: Wi-Fi (Built-in) | 3 HDMI ports to connect set top box, Blu Ray players, gaming console | 2 USB ports to connect hard drives and other USB devices | eARC | Bluetooth 5.0 | Optical | Ethernet\r\n                    Sound: 20 Watts Output | 2.0 Ch Speaker | AI Sound (Virtual Surround 5.1) for an Immersive Experience | AI Acoustic Tuning | Bluetooth Surround Ready.', 43990.00, 71990.00, 39, 'uploads/productImages/15/LG2.jpg', 'uploads/productImages/15/LG2.1.jpg', 'uploads/productImages/15/LG2.2.jpg', '2025-02-08 04:16:15', 1, 0, 0, 10),
(16, 3, 7, 'HP (15s-fq5007TU) Intel Core i3 12th Gen 1215U - (8 GB/512 GB SSD/Windows 11 Home)', 'Do your thing, all day and wherever you prefer, \r\n                    thanks to the HP 15.6\" Laptop PC with a lightweight design and long battery life[1]. \r\n                    Enjoy comfortable computing with a flicker-free screen[2] and experience reliable performance thanks to the\r\n                     Intel® Core™ Processor[3]. Plus, made with the planet in mind, is EPEAT® Silver registered[4] and ENERGY STAR® certified.', 49499.00, 62963.00, 20, 'uploads/productImages/16/HP1.jpg', 'uploads/productImages/16/HP1.2.jpg', 'uploads/productImages/16/HP1.3.jpg', '2025-02-08 04:19:43', 1, 0, 0, 10),
(17, 3, 7, 'HP Pavilion 14 Laptop (12th Gen Core i5 / 16GB RAM/ 512 GB SSD/ 14 inch (35.6 cm) Display/ Intel Iris Xe Graphics/ Windows 11/ Office) DV2014TU', 'Experience the perfect blend of performance and portability with the ASUS VivoBook S14. \r\n                Powered by the latest 11th Generation Intel Core i5 processor, this laptop delivers \r\n                exceptional performance for all your computing needs. The 15.6-inch Full HD display \r\n                provides stunning visuals, while the sleek design and lightweight construction make \r\n                it perfect for on-the-go productivity.', 63990.00, 81356.00, 21, 'uploads/productImages/17/HP2.jpg', 'uploads/productImages/17/HP2.3.jpg', 'uploads/productImages/17/HP2.1.jpg', '2025-02-08 04:24:04', 1, 0, 0, 10),
(18, 3, 6, 'Dell 15 Thin & Light Laptop,( Intel Core i5-1235U Processor/16GB DDR4+512GB)', 'Dell Inspiron 15 is a Windows 10 Home laptop with a 15.60-inch display that has a resolution of 1920x1080 pixels.\r\n                     It is powered by a Core i5 processor and it comes with 8GB of RAM. The Dell Inspiron 15 packs 1TB of HDD storage', 49990.00, 67457.00, 26, 'uploads/productImages/18/Dell2.jpg', 'uploads/productImages/18/Dell2.1.jpg', 'uploads/productImages/18/Dell2.3.jpg', '2025-02-08 04:26:51', 1, 0, 0, 10),
(19, 3, 8, 'ASUS TUF Gaming A15, 15.6\" (39.62 cms) FHD 144Hz, AMD Ryzen 7 4800H, 4GB GeForce RTX 3050 Graphics,                  Gaming Laptop (16GB/512GB SSD/90WHrs Battery/Windows 11/Black/2.3 kg), FA506ICB-HN075W ', 'Discover the ASUS TUF Gaming A15 laptops. Benefit from their impressive performance, sturdy design, and exceptional gaming capabilities. A perfect choice for gamers and professionals seeking dependable, high-quality, and budget-conscious devices. \r\n                Explore the ASUS TUF Gaming A15 and enjoy premium features at a great value.', 89990.00, 135999.00, 35, 'uploads/productImages/19/Asus2.jpg', 'uploads/productImages/19/Asus2.2.jpg', 'uploads/productImages/19/Asus2.3.jpg', '2025-02-08 04:28:27', 1, 0, 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL,
  `comments` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `name`, `rating`, `comments`, `created_at`) VALUES
(1, 1, 'Gauri Dalavi', 5, 'very nice product', '2025-02-18 11:47:35'),
(2, 4, 'Sargam yadav', 5, 'very nice', '2025-02-18 11:52:23');

-- --------------------------------------------------------

--
-- Table structure for table `userprofile`
--

CREATE TABLE `userprofile` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userprofile`
--

INSERT INTO `userprofile` (`id`, `user_id`, `first_name`, `phone`, `address`, `city`, `state`, `zip`, `created_at`, `updated_at`) VALUES
(1, 1, 'gauri', '9579926080', 'At post-masur', 'karad', 'maharashtra', '415106', '2025-02-18 12:04:49', '2025-02-18 12:05:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'Gauri', 'gauridalavi1@gmail.com', '$2y$10$xCUFOr9R5tuYvzCxXU6J7OEsBL13VX0rCfQdfZZjbh9Ngb7V3I32W', '2025-02-18 11:37:23'),
(2, 'Sargam', 'sargam116@gmail.com', '$2y$10$BH9UIZkfPmoLwatyysNcIOEGtVxoNX3YopwwjciTZ3aP0/HPzAM3q', '2025-02-18 11:49:31'),
(3, 'Sakshi', 'sakshichavan11@gmail.com', '$2y$10$2E0BAKuSCtfvUNEpB4gqjejsmWz4HAy18l0HYGoYj7YHchOJmb/di', '2025-02-18 11:55:01');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `created_at`) VALUES
(1, 2, 3, '2025-02-18 11:53:23'),
(2, 3, 5, '2025-02-18 11:56:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_cart_product` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fkbrand_id` (`brand_id`),
  ADD KEY `fkcategories_id` (`category_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `userprofile`
--
ALTER TABLE `userprofile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`product_id`),
  ADD KEY `wishlist_ibfk_2` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `userprofile`
--
ALTER TABLE `userprofile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `brands`
--
ALTER TABLE `brands`
  ADD CONSTRAINT `brands_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fkbrand_id` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkcategories_id` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `userprofile`
--
ALTER TABLE `userprofile`
  ADD CONSTRAINT `userprofile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
