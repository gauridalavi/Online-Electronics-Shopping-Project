<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo "Error: User not logged in.";
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = $_POST['amount'] ?? 0;
$card_number = $_POST['card_number'] ?? '';
$expiry_date = $_POST['expiry_date'] ?? '';
$cvv = $_POST['cvv'] ?? '';

// Simulate payment gateway API request (replace this with actual API call)
$payment_successful = simulateCardPayment($card_number, $expiry_date, $cvv, $amount);

if ($payment_successful) {
    // Mark order as paid in the database
    $conn = new mysqli('localhost', 'root', '', 'eshop');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $orderQuery = "INSERT INTO orders (user_id, total_price, payment_method, ) VALUES (?, ?, 'Card')";
    $stmt = $conn->prepare($orderQuery);
    $stmt->bind_param("ii", $user_id, $amount);
    $stmt->execute();

    // Get the new order ID
    $orderID = $stmt->insert_id;

    // Redirect to success page
    header("Location: success.php?orderID=" . $orderID);
    exit();
} else {
    echo "Payment failed. Please try again.";
    exit();
}

// This function simulates the card payment (replace with actual API)
function simulateCardPayment($card_number, $expiry_date, $cvv, $amount) {
    // Replace this logic with an actual API call to the payment processor
    return true; // Simulate a successful payment
}
?>
