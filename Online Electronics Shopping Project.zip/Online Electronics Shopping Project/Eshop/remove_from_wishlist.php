<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'eshop');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wishlist_id'])) {
    $wishlist_id = intval($_POST['wishlist_id']); // Get the wishlist item ID

    if ($wishlist_id > 0) {
        // Prepare and execute DELETE query to remove the wishlist item
        $query = "DELETE FROM wishlist WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $wishlist_id);

        if ($stmt->execute()) {
            // Redirect to the wishlist page after successful removal
            header("Location: wishlist.php");
            exit();
        } else {
            // Error handling if the query fails
            echo "Error removing item: " . $conn->error;
        }
        $stmt->close();
    } else {
        echo "Invalid wishlist item ID.";
    }
}

$conn->close();
?>
