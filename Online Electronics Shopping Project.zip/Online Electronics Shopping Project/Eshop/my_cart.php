<?php
// Start the session
session_start();
include('database/db_connect.php'); // Include your database connection file


// Check if the user is logged in
// Check if the user is logged in
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    // Redirect to login page with return URL
    header("Location: login.php?return=my_cart.php");
    exit();
}


// Fetch user data from the session
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    echo "Error: User ID not found in session.";
    exit();
}

// Handle Add to Cart functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve product data from the form
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $product_price = isset($_POST['product_price']) ? floatval($_POST['product_price']) : 0.0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

    // Validate input data
    if ($product_id > 0 && $quantity > 0) {
        // Calculate total price
        $total_price = $product_price * $quantity;

        // Check if the product already exists in the cart
        $query = "SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("ii", $user_id, $product_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                // Update quantity and total price
                $row = $result->fetch_assoc();
                $new_quantity = $row['quantity'] + $quantity;
                $new_total_price = $product_price * $new_quantity;

                $update_query = "UPDATE cart SET quantity = ?, total_price = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("idi", $new_quantity, $new_total_price, $row['id']);
                $update_stmt->execute();
                $update_stmt->close();
            } else {
                // Insert the new product into the cart
                $insert_query = "INSERT INTO cart (user_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->bind_param("iiid", $user_id, $product_id, $quantity, $total_price);
                $insert_stmt->execute();
                $insert_stmt->close();
            }
            $stmt->close();
        }
    }
}

// Fetch cart items for the logged-in user
$cartItems = [];
$query = "SELECT c.*, p.name AS product_name, p.image_main AS image_main, p.price 
          FROM cart c
          JOIN products p ON c.product_id = p.id
          WHERE c.user_id = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $cartItems[] = $row;
        }
    }
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
    <?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <link rel="stylesheet" href="css/footer.css">

    <link rel="stylesheet" href="css/cart_form.css">

</head>
<body>
    <div class="form-body">
<div class="cart-container">
    <h1>My Cart</h1>

    <!-- Cart Table -->
    <?php if (!empty($cartItems)): ?>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $grandTotal = 0;
                foreach ($cartItems as $item): 
                    $itemTotal = $item['price'] * $item['quantity'];
                    $grandTotal += $itemTotal;
                ?>
                    <tr>
                        <td>
                            <img src="Admin/<?php echo htmlspecialchars($item['image_main']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                            <br><?php echo htmlspecialchars($item['product_name']); ?>
                        </td>
                        <td>₹<?php echo htmlspecialchars($item['price']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td>₹<?php echo number_format($itemTotal, 2); ?></td>
                        <td>
                            <form method="POST" action="remove_from_cart.php">
                                <input type="hidden" name="cart_id" value="<?php echo htmlspecialchars($item['id']); ?>">
                                <button type="submit" style="background-color: #ff4d4f; color: white; padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer;">Remove</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="3">Total:</td>
                    <td colspan="2">₹<?php echo number_format($grandTotal, 2); ?></td>
                </tr>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; font-size: 18px;">Your cart is empty.</p>
    <?php endif; ?>

    <!-- Cart Buttons -->
    <div class="cart-buttons">
        <button class="continue" onclick="window.location.href='index.php';">Continue Shopping</button>
        <button class="checkout" onclick="window.location.href='checkout.php';">Proceed to Checkout</button>
    </div>
</div>
    </div>
<?php include('./components/footer.php'); ?>

</body>
</html>
