<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'eshop');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_id'])) {
    $cart_id = intval($_POST['cart_id']);

    $query = "DELETE FROM cart WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $cart_id);
    if ($stmt->execute()) {
        header("Location: my_cart.php");
        exit();
    } else {
        echo "Error removing item: " . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>
