<?php
// Start session
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check user authentication
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    header("Location: login.php?return=checkout.php");
    exit();
}

// Get user ID
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    echo "Error: User ID not found in session.";
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cart items
$sql = "SELECT * FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate the total price
$total_price = 0;
foreach ($cart_items as $item) {
    $total_price += $item['total_price'] * $item['quantity'];
}

// Fetch user profile details
$sql_profile = "SELECT first_name, phone, address, city, state, zip FROM userprofile WHERE user_id = ?";
$stmt_profile = $conn->prepare($sql_profile);
$stmt_profile->bind_param("i", $user_id);
$stmt_profile->execute();
$user_data = $stmt_profile->get_result()->fetch_assoc();

// Close connections
$stmt->close();
$stmt_profile->close();
$conn->close();
?>

<?php include('./components/header.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="css/checkout_form.css">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <div class="form-body">
        <div class="checkout-container">
            <form action="process_checkout.php" method="POST">
                <div class="form-section">
                    <center><h1>Checkout Form</h1></center>
                    <h3>Shipping Address</h3>
                    
                    <div class="form-group">
                        <label for="fullName">Full Name</label>
                        <input type="text" name="fullName" id="fullName" value="<?php echo htmlspecialchars($user_data['first_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" name="phone" id="phone" value="<?php echo htmlspecialchars($user_data['phone'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" name="address" id="address" value="<?php echo htmlspecialchars($user_data['address'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="city">City</label>
                        <input type="text" name="city" id="city" value="<?php echo htmlspecialchars($user_data['city'] ?? ''); ?>" required>
                    </div>
                    <div class="state-zip">
                        <div class="form-group">
                            <label for="state">State</label>
                            <input type="text" name="state" id="state" value="<?php echo htmlspecialchars($user_data['state'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="zip">Zip</label>
                            <input type="text" name="zip" id="zip" value="<?php echo htmlspecialchars($user_data['zip'] ?? ''); ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Hidden total price field -->
                <input type="hidden" name="total_price" value="<?php echo $total_price; ?>">

                <button type="submit" class="payment-btn">Payment Methods</button>
            </form>
        </div>
    </div>

    <?php include('./components/footer.php'); ?>
</body>
</html>
