<?php

session_start();
if (!isset($_SESSION['isLoggedIn']) || !$_SESSION['isLoggedIn']) {
    header("Location: login.php?return=checkout.php");
    exit();
}

if (!isset($_SESSION['customer_details']) || !isset($_SESSION['cart_items'])) {
    die("Error: Missing required session data.");
}
$payment_id = $_GET['payment_id'] ?? null; // Null for COD
$payment_method = $_GET['method'] ?? 'online'; // Default is 'online'

if ($payment_method === 'cod') {
    $payment_id = null; // No payment ID for COD
}

// Continue inserting the order into the database
$conn = new mysqli('localhost', 'root', '', 'eshop');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$customer = $_SESSION['customer_details'];
$cart_items = $_SESSION['cart_items'];
$total_price = $_SESSION['total_price'];
$user_id = $_SESSION['user_id'];

// Combine shipping address fields
$shipping_address = $customer['address'] . ", " . $customer['city'] . ", " . $customer['state'] . ", " . $customer['zip'];

// Insert order into database
$order_query = "INSERT INTO orders (user_id, total_price, payment_method, payment_id, full_name, email, phone_no, shipping_address) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($order_query);
$full_name = $customer['name'];
$email = $customer['email'];
$phone = $customer['phone'];

// Bind parameters (allow NULL for payment ID)
$stmt->bind_param("idssssss", $user_id, $total_price, $payment_method, $payment_id, $full_name, $email, $phone, $shipping_address);

if ($stmt->execute()) {
    $order_id = $stmt->insert_id;

    // Insert cart items into orders (if you use order_items table)
    $item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
    $item_stmt = $conn->prepare($item_query);

    foreach ($cart_items as $item) {
        $item_stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['total_price']);
        $item_stmt->execute();
    }

    // Clear cart after order
    $clear_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $clear_cart->bind_param("i", $user_id);
    $clear_cart->execute();

    // Redirect to order history
    header("Location: order_history.php?order_id=" . $order_id);
    exit();
} else {
    die("Error: " . $stmt->error);
}
?>